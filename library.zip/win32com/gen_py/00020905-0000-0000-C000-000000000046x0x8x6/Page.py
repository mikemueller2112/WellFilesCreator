# -*- coding: mbcs -*-
# Created by makepy.py version 0.5.01
# By python version 2.7.10 (default, May 23 2015, 09:40:32) [MSC v.1500 32 bit (Intel)]
# From type library '{00020905-0000-0000-C000-000000000046}'
# On Thu Jun 11 14:28:53 2015
'Microsoft Word 15.0 Object Library'
makepy_version = '0.5.01'
python_version = 0x2070af0

import win32com.client.CLSIDToClass, pythoncom, pywintypes
import win32com.client.util
from pywintypes import IID
from win32com.client import Dispatch

# The following 3 lines may need tweaking for the particular server
# Candidates are pythoncom.Missing, .Empty and .ArgNotFound
defaultNamedOptArg=pythoncom.Empty
defaultNamedNotOptArg=pythoncom.Empty
defaultUnnamedArg=pythoncom.Empty

CLSID = IID('{00020905-0000-0000-C000-000000000046}')
MajorVersion = 8
MinorVersion = 6
LibraryFlags = 8
LCID = 0x0

from win32com.client import DispatchBaseClass
class Page(DispatchBaseClass):
	CLSID = IID('{352840A9-AF7D-4CA4-87FC-21C68FDAB3E4}')
	coclass_clsid = None

	def SaveAsPNG(self, FileName=defaultNamedNotOptArg):
		return self._oleobj_.InvokeTypes(200, LCID, 1, (24, 0), ((8, 1),),FileName
			)

	_prop_map_get_ = {
		# Method 'Application' returns object of type 'Application'
		"Application": (1000, 2, (13, 0), (), "Application", '{000209FF-0000-0000-C000-000000000046}'),
		# Method 'Breaks' returns object of type 'Breaks'
		"Breaks": (7, 2, (9, 0), (), "Breaks", '{16BE9309-D708-4322-BB1A-B056F58D17EA}'),
		"Creator": (1001, 2, (3, 0), (), "Creator", None),
		"EnhMetaFileBits": (8, 2, (12, 0), (), "EnhMetaFileBits", None),
		"Height": (5, 2, (3, 0), (), "Height", None),
		"Left": (2, 2, (3, 0), (), "Left", None),
		"Parent": (1002, 2, (9, 0), (), "Parent", None),
		# Method 'Rectangles' returns object of type 'Rectangles'
		"Rectangles": (6, 2, (9, 0), (), "Rectangles", '{7D0F7985-68D9-4D93-91CB-8109280E76CC}'),
		"Top": (3, 2, (3, 0), (), "Top", None),
		"Width": (4, 2, (3, 0), (), "Width", None),
	}
	_prop_map_put_ = {
	}
	def __iter__(self):
		"Return a Python iterator for this object"
		try:
			ob = self._oleobj_.InvokeTypes(-4,LCID,3,(13, 10),())
		except pythoncom.error:
			raise TypeError("This object does not support enumeration")
		return win32com.client.util.Iterator(ob, None)

win32com.client.CLSIDToClass.RegisterCLSID( "{352840A9-AF7D-4CA4-87FC-21C68FDAB3E4}", Page )
# -*- coding: mbcs -*-
# Created by makepy.py version 0.5.01
# By python version 2.7.10 (default, May 23 2015, 09:40:32) [MSC v.1500 32 bit (Intel)]
# From type library '{00020905-0000-0000-C000-000000000046}'
# On Thu Jun 11 14:28:53 2015
'Microsoft Word 15.0 Object Library'
makepy_version = '0.5.01'
python_version = 0x2070af0

import win32com.client.CLSIDToClass, pythoncom, pywintypes
import win32com.client.util
from pywintypes import IID
from win32com.client import Dispatch

# The following 3 lines may need tweaking for the particular server
# Candidates are pythoncom.Missing, .Empty and .ArgNotFound
defaultNamedOptArg=pythoncom.Empty
defaultNamedNotOptArg=pythoncom.Empty
defaultUnnamedArg=pythoncom.Empty

CLSID = IID('{00020905-0000-0000-C000-000000000046}')
MajorVersion = 8
MinorVersion = 6
LibraryFlags = 8
LCID = 0x0

Page_vtables_dispatch_ = 1
Page_vtables_ = [
	(( u'Application' , u'prop' , ), 1000, (1000, (), [ (16397, 10, None, "IID('{000209FF-0000-0000-C000-000000000046}')") , ], 1 , 2 , 4 , 0 , 28 , (3, 0, None, None) , 0 , )),
	(( u'Creator' , u'prop' , ), 1001, (1001, (), [ (16387, 10, None, None) , ], 1 , 2 , 4 , 0 , 32 , (3, 0, None, None) , 0 , )),
	(( u'Parent' , u'prop' , ), 1002, (1002, (), [ (16393, 10, None, None) , ], 1 , 2 , 4 , 0 , 36 , (3, 0, None, None) , 0 , )),
	(( u'Left' , u'prop' , ), 2, (2, (), [ (16387, 10, None, None) , ], 1 , 2 , 4 , 0 , 40 , (3, 0, None, None) , 0 , )),
	(( u'Top' , u'prop' , ), 3, (3, (), [ (16387, 10, None, None) , ], 1 , 2 , 4 , 0 , 44 , (3, 0, None, None) , 0 , )),
	(( u'Width' , u'prop' , ), 4, (4, (), [ (16387, 10, None, None) , ], 1 , 2 , 4 , 0 , 48 , (3, 0, None, None) , 0 , )),
	(( u'Height' , u'prop' , ), 5, (5, (), [ (16387, 10, None, None) , ], 1 , 2 , 4 , 0 , 52 , (3, 0, None, None) , 0 , )),
	(( u'Rectangles' , u'prop' , ), 6, (6, (), [ (16393, 10, None, "IID('{7D0F7985-68D9-4D93-91CB-8109280E76CC}')") , ], 1 , 2 , 4 , 0 , 56 , (3, 0, None, None) , 0 , )),
	(( u'Breaks' , u'prop' , ), 7, (7, (), [ (16393, 10, None, "IID('{16BE9309-D708-4322-BB1A-B056F58D17EA}')") , ], 1 , 2 , 4 , 0 , 60 , (3, 0, None, None) , 0 , )),
	(( u'EnhMetaFileBits' , u'prop' , ), 8, (8, (), [ (16396, 10, None, None) , ], 1 , 2 , 4 , 0 , 64 , (3, 0, None, None) , 0 , )),
	(( u'SaveAsPNG' , u'FileName' , ), 200, (200, (), [ (8, 1, None, None) , ], 1 , 1 , 4 , 0 , 68 , (3, 0, None, None) , 64 , )),
]

win32com.client.CLSIDToClass.RegisterCLSID( "{352840A9-AF7D-4CA4-87FC-21C68FDAB3E4}", Page )
