# -*- coding: mbcs -*-
# Created by makepy.py version 0.5.01
# By python version 2.7.10 (default, May 23 2015, 09:40:32) [MSC v.1500 32 bit (Intel)]
# From type library '{00020905-0000-0000-C000-000000000046}'
# On Thu Jun 11 14:28:32 2015
'Microsoft Word 15.0 Object Library'
makepy_version = '0.5.01'
python_version = 0x2070af0

import win32com.client.CLSIDToClass, pythoncom, pywintypes
import win32com.client.util
from pywintypes import IID
from win32com.client import Dispatch

# The following 3 lines may need tweaking for the particular server
# Candidates are pythoncom.Missing, .Empty and .ArgNotFound
defaultNamedOptArg=pythoncom.Empty
defaultNamedNotOptArg=pythoncom.Empty
defaultUnnamedArg=pythoncom.Empty

CLSID = IID('{00020905-0000-0000-C000-000000000046}')
MajorVersion = 8
MinorVersion = 6
LibraryFlags = 8
LCID = 0x0

from win32com.client import DispatchBaseClass
class Window(DispatchBaseClass):
	CLSID = IID('{00020962-0000-0000-C000-000000000046}')
	coclass_clsid = None

	def Activate(self):
		return self._oleobj_.InvokeTypes(100, LCID, 1, (24, 0), (),)

	def Close(self, SaveChanges=defaultNamedOptArg, RouteDocument=defaultNamedOptArg):
		return self._oleobj_.InvokeTypes(102, LCID, 1, (24, 0), ((16396, 17), (16396, 17)),SaveChanges
			, RouteDocument)

	def GetPoint(self, ScreenPixelsLeft=pythoncom.Missing, ScreenPixelsTop=pythoncom.Missing, ScreenPixelsWidth=pythoncom.Missing, ScreenPixelsHeight=pythoncom.Missing
			, obj=defaultNamedNotOptArg):
		return self._ApplyTypes_(112, 1, (24, 0), ((16387, 2), (16387, 2), (16387, 2), (16387, 2), (9, 1)), u'GetPoint', None,ScreenPixelsLeft
			, ScreenPixelsTop, ScreenPixelsWidth, ScreenPixelsHeight, obj)

	def LargeScroll(self, Down=defaultNamedOptArg, Up=defaultNamedOptArg, ToRight=defaultNamedOptArg, ToLeft=defaultNamedOptArg):
		return self._oleobj_.InvokeTypes(103, LCID, 1, (24, 0), ((16396, 17), (16396, 17), (16396, 17), (16396, 17)),Down
			, Up, ToRight, ToLeft)

	# Result is of type Window
	def NewWindow(self):
		ret = self._oleobj_.InvokeTypes(105, LCID, 1, (9, 0), (),)
		if ret is not None:
			ret = Dispatch(ret, u'NewWindow', '{00020962-0000-0000-C000-000000000046}')
		return ret

	def PageScroll(self, Down=defaultNamedOptArg, Up=defaultNamedOptArg):
		return self._oleobj_.InvokeTypes(108, LCID, 1, (24, 0), ((16396, 17), (16396, 17)),Down
			, Up)

	def PrintOut(self, Background=defaultNamedOptArg, Append=defaultNamedOptArg, Range=defaultNamedOptArg, OutputFileName=defaultNamedOptArg
			, From=defaultNamedOptArg, To=defaultNamedOptArg, Item=defaultNamedOptArg, Copies=defaultNamedOptArg, Pages=defaultNamedOptArg
			, PageType=defaultNamedOptArg, PrintToFile=defaultNamedOptArg, Collate=defaultNamedOptArg, ActivePrinterMacGX=defaultNamedOptArg, ManualDuplexPrint=defaultNamedOptArg
			, PrintZoomColumn=defaultNamedOptArg, PrintZoomRow=defaultNamedOptArg, PrintZoomPaperWidth=defaultNamedOptArg, PrintZoomPaperHeight=defaultNamedOptArg):
		return self._oleobj_.InvokeTypes(445, LCID, 1, (24, 0), ((16396, 17), (16396, 17), (16396, 17), (16396, 17), (16396, 17), (16396, 17), (16396, 17), (16396, 17), (16396, 17), (16396, 17), (16396, 17), (16396, 17), (16396, 17), (16396, 17), (16396, 17), (16396, 17), (16396, 17), (16396, 17)),Background
			, Append, Range, OutputFileName, From, To
			, Item, Copies, Pages, PageType, PrintToFile
			, Collate, ActivePrinterMacGX, ManualDuplexPrint, PrintZoomColumn, PrintZoomRow
			, PrintZoomPaperWidth, PrintZoomPaperHeight)

	def PrintOut2000(self, Background=defaultNamedOptArg, Append=defaultNamedOptArg, Range=defaultNamedOptArg, OutputFileName=defaultNamedOptArg
			, From=defaultNamedOptArg, To=defaultNamedOptArg, Item=defaultNamedOptArg, Copies=defaultNamedOptArg, Pages=defaultNamedOptArg
			, PageType=defaultNamedOptArg, PrintToFile=defaultNamedOptArg, Collate=defaultNamedOptArg, ActivePrinterMacGX=defaultNamedOptArg, ManualDuplexPrint=defaultNamedOptArg
			, PrintZoomColumn=defaultNamedOptArg, PrintZoomRow=defaultNamedOptArg, PrintZoomPaperWidth=defaultNamedOptArg, PrintZoomPaperHeight=defaultNamedOptArg):
		return self._oleobj_.InvokeTypes(444, LCID, 1, (24, 0), ((16396, 17), (16396, 17), (16396, 17), (16396, 17), (16396, 17), (16396, 17), (16396, 17), (16396, 17), (16396, 17), (16396, 17), (16396, 17), (16396, 17), (16396, 17), (16396, 17), (16396, 17), (16396, 17), (16396, 17), (16396, 17)),Background
			, Append, Range, OutputFileName, From, To
			, Item, Copies, Pages, PageType, PrintToFile
			, Collate, ActivePrinterMacGX, ManualDuplexPrint, PrintZoomColumn, PrintZoomRow
			, PrintZoomPaperWidth, PrintZoomPaperHeight)

	def PrintOutOld(self, Background=defaultNamedOptArg, Append=defaultNamedOptArg, Range=defaultNamedOptArg, OutputFileName=defaultNamedOptArg
			, From=defaultNamedOptArg, To=defaultNamedOptArg, Item=defaultNamedOptArg, Copies=defaultNamedOptArg, Pages=defaultNamedOptArg
			, PageType=defaultNamedOptArg, PrintToFile=defaultNamedOptArg, Collate=defaultNamedOptArg, ActivePrinterMacGX=defaultNamedOptArg, ManualDuplexPrint=defaultNamedOptArg):
		return self._oleobj_.InvokeTypes(107, LCID, 1, (24, 0), ((16396, 17), (16396, 17), (16396, 17), (16396, 17), (16396, 17), (16396, 17), (16396, 17), (16396, 17), (16396, 17), (16396, 17), (16396, 17), (16396, 17), (16396, 17), (16396, 17)),Background
			, Append, Range, OutputFileName, From, To
			, Item, Copies, Pages, PageType, PrintToFile
			, Collate, ActivePrinterMacGX, ManualDuplexPrint)

	def RangeFromPoint(self, x=defaultNamedNotOptArg, y=defaultNamedNotOptArg):
		ret = self._oleobj_.InvokeTypes(110, LCID, 1, (9, 0), ((3, 1), (3, 1)),x
			, y)
		if ret is not None:
			ret = Dispatch(ret, u'RangeFromPoint', None)
		return ret

	def ScrollIntoView(self, obj=defaultNamedNotOptArg, Start=defaultNamedOptArg):
		return self._oleobj_.InvokeTypes(111, LCID, 1, (24, 0), ((9, 1), (16396, 17)),obj
			, Start)

	def SetFocus(self):
		return self._oleobj_.InvokeTypes(109, LCID, 1, (24, 0), (),)

	def SmallScroll(self, Down=defaultNamedOptArg, Up=defaultNamedOptArg, ToRight=defaultNamedOptArg, ToLeft=defaultNamedOptArg):
		return self._oleobj_.InvokeTypes(104, LCID, 1, (24, 0), ((16396, 17), (16396, 17), (16396, 17), (16396, 17)),Down
			, Up, ToRight, ToLeft)

	def ToggleRibbon(self):
		return self._oleobj_.InvokeTypes(447, LCID, 1, (24, 0), (),)

	def ToggleShowAllReviewers(self):
		return self._oleobj_.InvokeTypes(446, LCID, 1, (24, 0), (),)

	_prop_map_get_ = {
		"Active": (26, 2, (11, 0), (), "Active", None),
		# Method 'ActivePane' returns object of type 'Pane'
		"ActivePane": (1, 2, (9, 0), (), "ActivePane", '{00020960-0000-0000-C000-000000000046}'),
		# Method 'Application' returns object of type 'Application'
		"Application": (1000, 2, (13, 0), (), "Application", '{000209FF-0000-0000-C000-000000000046}'),
		"Caption": (0, 2, (8, 0), (), "Caption", None),
		"Creator": (1001, 2, (3, 0), (), "Creator", None),
		"DisplayHorizontalScrollBar": (20, 2, (11, 0), (), "DisplayHorizontalScrollBar", None),
		"DisplayLeftScrollBar": (34, 2, (11, 0), (), "DisplayLeftScrollBar", None),
		"DisplayRightRuler": (35, 2, (11, 0), (), "DisplayRightRuler", None),
		"DisplayRulers": (12, 2, (11, 0), (), "DisplayRulers", None),
		"DisplayScreenTips": (22, 2, (11, 0), (), "DisplayScreenTips", None),
		"DisplayVerticalRuler": (13, 2, (11, 0), (), "DisplayVerticalRuler", None),
		"DisplayVerticalScrollBar": (19, 2, (11, 0), (), "DisplayVerticalScrollBar", None),
		# Method 'Document' returns object of type 'Document'
		"Document": (2, 2, (13, 0), (), "Document", '{00020906-0000-0000-C000-000000000046}'),
		"DocumentMap": (25, 2, (11, 0), (), "DocumentMap", None),
		"DocumentMapPercentWidth": (27, 2, (3, 0), (), "DocumentMapPercentWidth", None),
		"EnvelopeVisible": (33, 2, (11, 0), (), "EnvelopeVisible", None),
		"Height": (8, 2, (3, 0), (), "Height", None),
		"HorizontalPercentScrolled": (23, 2, (3, 0), (), "HorizontalPercentScrolled", None),
		"Hwnd": (39, 2, (3, 0), (), "Hwnd", None),
		"IMEMode": (30, 2, (3, 0), (), "IMEMode", None),
		"Index": (28, 2, (3, 0), (), "Index", None),
		"Left": (5, 2, (3, 0), (), "Left", None),
		# Method 'Next' returns object of type 'Window'
		"Next": (16, 2, (9, 0), (), "Next", '{00020962-0000-0000-C000-000000000046}'),
		# Method 'Panes' returns object of type 'Panes'
		"Panes": (3, 2, (9, 0), (), "Panes", '{0002095F-0000-0000-C000-000000000046}'),
		"Parent": (1002, 2, (9, 0), (), "Parent", None),
		# Method 'Previous' returns object of type 'Window'
		"Previous": (17, 2, (9, 0), (), "Previous", '{00020962-0000-0000-C000-000000000046}'),
		# Method 'Selection' returns object of type 'Selection'
		"Selection": (4, 2, (9, 0), (), "Selection", '{00020975-0000-0000-C000-000000000046}'),
		"ShowSourceDocuments": (38, 2, (3, 0), (), "ShowSourceDocuments", None),
		"Split": (9, 2, (11, 0), (), "Split", None),
		"SplitVertical": (10, 2, (3, 0), (), "SplitVertical", None),
		"StyleAreaWidth": (21, 2, (4, 0), (), "StyleAreaWidth", None),
		"Thumbnails": (37, 2, (11, 0), (), "Thumbnails", None),
		"Top": (6, 2, (3, 0), (), "Top", None),
		"Type": (15, 2, (3, 0), (), "Type", None),
		"UsableHeight": (32, 2, (3, 0), (), "UsableHeight", None),
		"UsableWidth": (31, 2, (3, 0), (), "UsableWidth", None),
		"VerticalPercentScrolled": (24, 2, (3, 0), (), "VerticalPercentScrolled", None),
		# Method 'View' returns object of type 'View'
		"View": (14, 2, (9, 0), (), "View", '{000209A5-0000-0000-C000-000000000046}'),
		"Visible": (36, 2, (11, 0), (), "Visible", None),
		"Width": (7, 2, (3, 0), (), "Width", None),
		"WindowNumber": (18, 2, (3, 0), (), "WindowNumber", None),
		"WindowState": (11, 2, (3, 0), (), "WindowState", None),
	}
	_prop_map_put_ = {
		"Caption": ((0, LCID, 4, 0),()),
		"DisplayHorizontalScrollBar": ((20, LCID, 4, 0),()),
		"DisplayLeftScrollBar": ((34, LCID, 4, 0),()),
		"DisplayRightRuler": ((35, LCID, 4, 0),()),
		"DisplayRulers": ((12, LCID, 4, 0),()),
		"DisplayScreenTips": ((22, LCID, 4, 0),()),
		"DisplayVerticalRuler": ((13, LCID, 4, 0),()),
		"DisplayVerticalScrollBar": ((19, LCID, 4, 0),()),
		"DocumentMap": ((25, LCID, 4, 0),()),
		"DocumentMapPercentWidth": ((27, LCID, 4, 0),()),
		"EnvelopeVisible": ((33, LCID, 4, 0),()),
		"Height": ((8, LCID, 4, 0),()),
		"HorizontalPercentScrolled": ((23, LCID, 4, 0),()),
		"IMEMode": ((30, LCID, 4, 0),()),
		"Left": ((5, LCID, 4, 0),()),
		"ShowSourceDocuments": ((38, LCID, 4, 0),()),
		"Split": ((9, LCID, 4, 0),()),
		"SplitVertical": ((10, LCID, 4, 0),()),
		"StyleAreaWidth": ((21, LCID, 4, 0),()),
		"Thumbnails": ((37, LCID, 4, 0),()),
		"Top": ((6, LCID, 4, 0),()),
		"VerticalPercentScrolled": ((24, LCID, 4, 0),()),
		"Visible": ((36, LCID, 4, 0),()),
		"Width": ((7, LCID, 4, 0),()),
		"WindowState": ((11, LCID, 4, 0),()),
	}
	# Default property for this class is 'Caption'
	def __call__(self):
		return self._ApplyTypes_(*(0, 2, (8, 0), (), "Caption", None))
	def __unicode__(self, *args):
		try:
			return unicode(self.__call__(*args))
		except pythoncom.com_error:
			return repr(self)
	def __str__(self, *args):
		return str(self.__unicode__(*args))
	def __int__(self, *args):
		return int(self.__call__(*args))
	def __iter__(self):
		"Return a Python iterator for this object"
		try:
			ob = self._oleobj_.InvokeTypes(-4,LCID,3,(13, 10),())
		except pythoncom.error:
			raise TypeError("This object does not support enumeration")
		return win32com.client.util.Iterator(ob, None)

win32com.client.CLSIDToClass.RegisterCLSID( "{00020962-0000-0000-C000-000000000046}", Window )
# -*- coding: mbcs -*-
# Created by makepy.py version 0.5.01
# By python version 2.7.10 (default, May 23 2015, 09:40:32) [MSC v.1500 32 bit (Intel)]
# From type library '{00020905-0000-0000-C000-000000000046}'
# On Thu Jun 11 14:28:32 2015
'Microsoft Word 15.0 Object Library'
makepy_version = '0.5.01'
python_version = 0x2070af0

import win32com.client.CLSIDToClass, pythoncom, pywintypes
import win32com.client.util
from pywintypes import IID
from win32com.client import Dispatch

# The following 3 lines may need tweaking for the particular server
# Candidates are pythoncom.Missing, .Empty and .ArgNotFound
defaultNamedOptArg=pythoncom.Empty
defaultNamedNotOptArg=pythoncom.Empty
defaultUnnamedArg=pythoncom.Empty

CLSID = IID('{00020905-0000-0000-C000-000000000046}')
MajorVersion = 8
MinorVersion = 6
LibraryFlags = 8
LCID = 0x0

Window_vtables_dispatch_ = 1
Window_vtables_ = [
	(( u'Application' , u'prop' , ), 1000, (1000, (), [ (16397, 10, None, "IID('{000209FF-0000-0000-C000-000000000046}')") , ], 1 , 2 , 4 , 0 , 28 , (3, 0, None, None) , 0 , )),
	(( u'Creator' , u'prop' , ), 1001, (1001, (), [ (16387, 10, None, None) , ], 1 , 2 , 4 , 0 , 32 , (3, 0, None, None) , 0 , )),
	(( u'Parent' , u'prop' , ), 1002, (1002, (), [ (16393, 10, None, None) , ], 1 , 2 , 4 , 0 , 36 , (3, 0, None, None) , 0 , )),
	(( u'ActivePane' , u'prop' , ), 1, (1, (), [ (16393, 10, None, "IID('{00020960-0000-0000-C000-000000000046}')") , ], 1 , 2 , 4 , 0 , 40 , (3, 0, None, None) , 0 , )),
	(( u'Document' , u'prop' , ), 2, (2, (), [ (16397, 10, None, "IID('{00020906-0000-0000-C000-000000000046}')") , ], 1 , 2 , 4 , 0 , 44 , (3, 0, None, None) , 0 , )),
	(( u'Panes' , u'prop' , ), 3, (3, (), [ (16393, 10, None, "IID('{0002095F-0000-0000-C000-000000000046}')") , ], 1 , 2 , 4 , 0 , 48 , (3, 0, None, None) , 0 , )),
	(( u'Selection' , u'prop' , ), 4, (4, (), [ (16393, 10, None, "IID('{00020975-0000-0000-C000-000000000046}')") , ], 1 , 2 , 4 , 0 , 52 , (3, 0, None, None) , 0 , )),
	(( u'Left' , u'prop' , ), 5, (5, (), [ (16387, 10, None, None) , ], 1 , 2 , 4 , 0 , 56 , (3, 0, None, None) , 0 , )),
	(( u'Left' , u'prop' , ), 5, (5, (), [ (3, 1, None, None) , ], 1 , 4 , 4 , 0 , 60 , (3, 0, None, None) , 0 , )),
	(( u'Top' , u'prop' , ), 6, (6, (), [ (16387, 10, None, None) , ], 1 , 2 , 4 , 0 , 64 , (3, 0, None, None) , 0 , )),
	(( u'Top' , u'prop' , ), 6, (6, (), [ (3, 1, None, None) , ], 1 , 4 , 4 , 0 , 68 , (3, 0, None, None) , 0 , )),
	(( u'Width' , u'prop' , ), 7, (7, (), [ (16387, 10, None, None) , ], 1 , 2 , 4 , 0 , 72 , (3, 0, None, None) , 0 , )),
	(( u'Width' , u'prop' , ), 7, (7, (), [ (3, 1, None, None) , ], 1 , 4 , 4 , 0 , 76 , (3, 0, None, None) , 0 , )),
	(( u'Height' , u'prop' , ), 8, (8, (), [ (16387, 10, None, None) , ], 1 , 2 , 4 , 0 , 80 , (3, 0, None, None) , 0 , )),
	(( u'Height' , u'prop' , ), 8, (8, (), [ (3, 1, None, None) , ], 1 , 4 , 4 , 0 , 84 , (3, 0, None, None) , 0 , )),
	(( u'Split' , u'prop' , ), 9, (9, (), [ (16395, 10, None, None) , ], 1 , 2 , 4 , 0 , 88 , (3, 0, None, None) , 0 , )),
	(( u'Split' , u'prop' , ), 9, (9, (), [ (11, 1, None, None) , ], 1 , 4 , 4 , 0 , 92 , (3, 0, None, None) , 0 , )),
	(( u'SplitVertical' , u'prop' , ), 10, (10, (), [ (16387, 10, None, None) , ], 1 , 2 , 4 , 0 , 96 , (3, 0, None, None) , 0 , )),
	(( u'SplitVertical' , u'prop' , ), 10, (10, (), [ (3, 1, None, None) , ], 1 , 4 , 4 , 0 , 100 , (3, 0, None, None) , 0 , )),
	(( u'Caption' , u'prop' , ), 0, (0, (), [ (16392, 10, None, None) , ], 1 , 2 , 4 , 0 , 104 , (3, 0, None, None) , 0 , )),
	(( u'Caption' , u'prop' , ), 0, (0, (), [ (8, 1, None, None) , ], 1 , 4 , 4 , 0 , 108 , (3, 0, None, None) , 0 , )),
	(( u'WindowState' , u'prop' , ), 11, (11, (), [ (16387, 10, None, None) , ], 1 , 2 , 4 , 0 , 112 , (3, 0, None, None) , 0 , )),
	(( u'WindowState' , u'prop' , ), 11, (11, (), [ (3, 1, None, None) , ], 1 , 4 , 4 , 0 , 116 , (3, 0, None, None) , 0 , )),
	(( u'DisplayRulers' , u'prop' , ), 12, (12, (), [ (16395, 10, None, None) , ], 1 , 2 , 4 , 0 , 120 , (3, 0, None, None) , 0 , )),
	(( u'DisplayRulers' , u'prop' , ), 12, (12, (), [ (11, 1, None, None) , ], 1 , 4 , 4 , 0 , 124 , (3, 0, None, None) , 0 , )),
	(( u'DisplayVerticalRuler' , u'prop' , ), 13, (13, (), [ (16395, 10, None, None) , ], 1 , 2 , 4 , 0 , 128 , (3, 0, None, None) , 0 , )),
	(( u'DisplayVerticalRuler' , u'prop' , ), 13, (13, (), [ (11, 1, None, None) , ], 1 , 4 , 4 , 0 , 132 , (3, 0, None, None) , 0 , )),
	(( u'View' , u'prop' , ), 14, (14, (), [ (16393, 10, None, "IID('{000209A5-0000-0000-C000-000000000046}')") , ], 1 , 2 , 4 , 0 , 136 , (3, 0, None, None) , 0 , )),
	(( u'Type' , u'prop' , ), 15, (15, (), [ (16387, 10, None, None) , ], 1 , 2 , 4 , 0 , 140 , (3, 0, None, None) , 0 , )),
	(( u'Next' , u'prop' , ), 16, (16, (), [ (16393, 10, None, "IID('{00020962-0000-0000-C000-000000000046}')") , ], 1 , 2 , 4 , 0 , 144 , (3, 0, None, None) , 0 , )),
	(( u'Previous' , u'prop' , ), 17, (17, (), [ (16393, 10, None, "IID('{00020962-0000-0000-C000-000000000046}')") , ], 1 , 2 , 4 , 0 , 148 , (3, 0, None, None) , 0 , )),
	(( u'WindowNumber' , u'prop' , ), 18, (18, (), [ (16387, 10, None, None) , ], 1 , 2 , 4 , 0 , 152 , (3, 0, None, None) , 0 , )),
	(( u'DisplayVerticalScrollBar' , u'prop' , ), 19, (19, (), [ (16395, 10, None, None) , ], 1 , 2 , 4 , 0 , 156 , (3, 0, None, None) , 0 , )),
	(( u'DisplayVerticalScrollBar' , u'prop' , ), 19, (19, (), [ (11, 1, None, None) , ], 1 , 4 , 4 , 0 , 160 , (3, 0, None, None) , 0 , )),
	(( u'DisplayHorizontalScrollBar' , u'prop' , ), 20, (20, (), [ (16395, 10, None, None) , ], 1 , 2 , 4 , 0 , 164 , (3, 0, None, None) , 0 , )),
	(( u'DisplayHorizontalScrollBar' , u'prop' , ), 20, (20, (), [ (11, 1, None, None) , ], 1 , 4 , 4 , 0 , 168 , (3, 0, None, None) , 0 , )),
	(( u'StyleAreaWidth' , u'prop' , ), 21, (21, (), [ (16388, 10, None, None) , ], 1 , 2 , 4 , 0 , 172 , (3, 0, None, None) , 0 , )),
	(( u'StyleAreaWidth' , u'prop' , ), 21, (21, (), [ (4, 1, None, None) , ], 1 , 4 , 4 , 0 , 176 , (3, 0, None, None) , 0 , )),
	(( u'DisplayScreenTips' , u'prop' , ), 22, (22, (), [ (16395, 10, None, None) , ], 1 , 2 , 4 , 0 , 180 , (3, 0, None, None) , 0 , )),
	(( u'DisplayScreenTips' , u'prop' , ), 22, (22, (), [ (11, 1, None, None) , ], 1 , 4 , 4 , 0 , 184 , (3, 0, None, None) , 0 , )),
	(( u'HorizontalPercentScrolled' , u'prop' , ), 23, (23, (), [ (16387, 10, None, None) , ], 1 , 2 , 4 , 0 , 188 , (3, 0, None, None) , 0 , )),
	(( u'HorizontalPercentScrolled' , u'prop' , ), 23, (23, (), [ (3, 1, None, None) , ], 1 , 4 , 4 , 0 , 192 , (3, 0, None, None) , 0 , )),
	(( u'VerticalPercentScrolled' , u'prop' , ), 24, (24, (), [ (16387, 10, None, None) , ], 1 , 2 , 4 , 0 , 196 , (3, 0, None, None) , 0 , )),
	(( u'VerticalPercentScrolled' , u'prop' , ), 24, (24, (), [ (3, 1, None, None) , ], 1 , 4 , 4 , 0 , 200 , (3, 0, None, None) , 0 , )),
	(( u'DocumentMap' , u'prop' , ), 25, (25, (), [ (16395, 10, None, None) , ], 1 , 2 , 4 , 0 , 204 , (3, 0, None, None) , 0 , )),
	(( u'DocumentMap' , u'prop' , ), 25, (25, (), [ (11, 1, None, None) , ], 1 , 4 , 4 , 0 , 208 , (3, 0, None, None) , 0 , )),
	(( u'Active' , u'prop' , ), 26, (26, (), [ (16395, 10, None, None) , ], 1 , 2 , 4 , 0 , 212 , (3, 0, None, None) , 0 , )),
	(( u'DocumentMapPercentWidth' , u'prop' , ), 27, (27, (), [ (16387, 10, None, None) , ], 1 , 2 , 4 , 0 , 216 , (3, 0, None, None) , 64 , )),
	(( u'DocumentMapPercentWidth' , u'prop' , ), 27, (27, (), [ (3, 1, None, None) , ], 1 , 4 , 4 , 0 , 220 , (3, 0, None, None) , 64 , )),
	(( u'Index' , u'prop' , ), 28, (28, (), [ (16387, 10, None, None) , ], 1 , 2 , 4 , 0 , 224 , (3, 0, None, None) , 0 , )),
	(( u'IMEMode' , u'prop' , ), 30, (30, (), [ (16387, 10, None, None) , ], 1 , 2 , 4 , 0 , 228 , (3, 0, None, None) , 0 , )),
	(( u'IMEMode' , u'prop' , ), 30, (30, (), [ (3, 1, None, None) , ], 1 , 4 , 4 , 0 , 232 , (3, 0, None, None) , 0 , )),
	(( u'Activate' , ), 100, (100, (), [ ], 1 , 1 , 4 , 0 , 236 , (3, 0, None, None) , 0 , )),
	(( u'Close' , u'SaveChanges' , u'RouteDocument' , ), 102, (102, (), [ (16396, 17, None, None) , 
			(16396, 17, None, None) , ], 1 , 1 , 4 , 2 , 240 , (3, 0, None, None) , 0 , )),
	(( u'LargeScroll' , u'Down' , u'Up' , u'ToRight' , u'ToLeft' , 
			), 103, (103, (), [ (16396, 17, None, None) , (16396, 17, None, None) , (16396, 17, None, None) , (16396, 17, None, None) , ], 1 , 1 , 4 , 4 , 244 , (3, 0, None, None) , 0 , )),
	(( u'SmallScroll' , u'Down' , u'Up' , u'ToRight' , u'ToLeft' , 
			), 104, (104, (), [ (16396, 17, None, None) , (16396, 17, None, None) , (16396, 17, None, None) , (16396, 17, None, None) , ], 1 , 1 , 4 , 4 , 248 , (3, 0, None, None) , 0 , )),
	(( u'NewWindow' , u'prop' , ), 105, (105, (), [ (16393, 10, None, "IID('{00020962-0000-0000-C000-000000000046}')") , ], 1 , 1 , 4 , 0 , 252 , (3, 0, None, None) , 0 , )),
	(( u'PrintOutOld' , u'Background' , u'Append' , u'Range' , u'OutputFileName' , 
			u'From' , u'To' , u'Item' , u'Copies' , u'Pages' , 
			u'PageType' , u'PrintToFile' , u'Collate' , u'ActivePrinterMacGX' , u'ManualDuplexPrint' , 
			), 107, (107, (), [ (16396, 17, None, None) , (16396, 17, None, None) , (16396, 17, None, None) , (16396, 17, None, None) , 
			(16396, 17, None, None) , (16396, 17, None, None) , (16396, 17, None, None) , (16396, 17, None, None) , (16396, 17, None, None) , 
			(16396, 17, None, None) , (16396, 17, None, None) , (16396, 17, None, None) , (16396, 17, None, None) , (16396, 17, None, None) , ], 1 , 1 , 4 , 14 , 256 , (3, 0, None, None) , 64 , )),
	(( u'PageScroll' , u'Down' , u'Up' , ), 108, (108, (), [ (16396, 17, None, None) , 
			(16396, 17, None, None) , ], 1 , 1 , 4 , 2 , 260 , (3, 0, None, None) , 0 , )),
	(( u'SetFocus' , ), 109, (109, (), [ ], 1 , 1 , 4 , 0 , 264 , (3, 0, None, None) , 0 , )),
	(( u'RangeFromPoint' , u'x' , u'y' , u'prop' , ), 110, (110, (), [ 
			(3, 1, None, None) , (3, 1, None, None) , (16393, 10, None, None) , ], 1 , 1 , 4 , 0 , 268 , (3, 0, None, None) , 0 , )),
	(( u'ScrollIntoView' , u'obj' , u'Start' , ), 111, (111, (), [ (9, 1, None, None) , 
			(16396, 17, None, None) , ], 1 , 1 , 4 , 1 , 272 , (3, 0, None, None) , 0 , )),
	(( u'GetPoint' , u'ScreenPixelsLeft' , u'ScreenPixelsTop' , u'ScreenPixelsWidth' , u'ScreenPixelsHeight' , 
			u'obj' , ), 112, (112, (), [ (16387, 2, None, None) , (16387, 2, None, None) , (16387, 2, None, None) , 
			(16387, 2, None, None) , (9, 1, None, None) , ], 1 , 1 , 4 , 0 , 276 , (3, 0, None, None) , 0 , )),
	(( u'PrintOut2000' , u'Background' , u'Append' , u'Range' , u'OutputFileName' , 
			u'From' , u'To' , u'Item' , u'Copies' , u'Pages' , 
			u'PageType' , u'PrintToFile' , u'Collate' , u'ActivePrinterMacGX' , u'ManualDuplexPrint' , 
			u'PrintZoomColumn' , u'PrintZoomRow' , u'PrintZoomPaperWidth' , u'PrintZoomPaperHeight' , ), 444, (444, (), [ 
			(16396, 17, None, None) , (16396, 17, None, None) , (16396, 17, None, None) , (16396, 17, None, None) , (16396, 17, None, None) , 
			(16396, 17, None, None) , (16396, 17, None, None) , (16396, 17, None, None) , (16396, 17, None, None) , (16396, 17, None, None) , 
			(16396, 17, None, None) , (16396, 17, None, None) , (16396, 17, None, None) , (16396, 17, None, None) , (16396, 17, None, None) , 
			(16396, 17, None, None) , (16396, 17, None, None) , (16396, 17, None, None) , ], 1 , 1 , 4 , 18 , 280 , (3, 0, None, None) , 64 , )),
	(( u'UsableWidth' , u'prop' , ), 31, (31, (), [ (16387, 10, None, None) , ], 1 , 2 , 4 , 0 , 284 , (3, 0, None, None) , 0 , )),
	(( u'UsableHeight' , u'prop' , ), 32, (32, (), [ (16387, 10, None, None) , ], 1 , 2 , 4 , 0 , 288 , (3, 0, None, None) , 0 , )),
	(( u'EnvelopeVisible' , u'prop' , ), 33, (33, (), [ (16395, 10, None, None) , ], 1 , 2 , 4 , 0 , 292 , (3, 0, None, None) , 0 , )),
	(( u'EnvelopeVisible' , u'prop' , ), 33, (33, (), [ (11, 1, None, None) , ], 1 , 4 , 4 , 0 , 296 , (3, 0, None, None) , 0 , )),
	(( u'DisplayRightRuler' , u'prop' , ), 35, (35, (), [ (16395, 10, None, None) , ], 1 , 2 , 4 , 0 , 300 , (3, 0, None, None) , 0 , )),
	(( u'DisplayRightRuler' , u'prop' , ), 35, (35, (), [ (11, 1, None, None) , ], 1 , 4 , 4 , 0 , 304 , (3, 0, None, None) , 0 , )),
	(( u'DisplayLeftScrollBar' , u'prop' , ), 34, (34, (), [ (16395, 10, None, None) , ], 1 , 2 , 4 , 0 , 308 , (3, 0, None, None) , 0 , )),
	(( u'DisplayLeftScrollBar' , u'prop' , ), 34, (34, (), [ (11, 1, None, None) , ], 1 , 4 , 4 , 0 , 312 , (3, 0, None, None) , 0 , )),
	(( u'Visible' , u'prop' , ), 36, (36, (), [ (16395, 10, None, None) , ], 1 , 2 , 4 , 0 , 316 , (3, 0, None, None) , 0 , )),
	(( u'Visible' , u'prop' , ), 36, (36, (), [ (11, 1, None, None) , ], 1 , 4 , 4 , 0 , 320 , (3, 0, None, None) , 0 , )),
	(( u'PrintOut' , u'Background' , u'Append' , u'Range' , u'OutputFileName' , 
			u'From' , u'To' , u'Item' , u'Copies' , u'Pages' , 
			u'PageType' , u'PrintToFile' , u'Collate' , u'ActivePrinterMacGX' , u'ManualDuplexPrint' , 
			u'PrintZoomColumn' , u'PrintZoomRow' , u'PrintZoomPaperWidth' , u'PrintZoomPaperHeight' , ), 445, (445, (), [ 
			(16396, 17, None, None) , (16396, 17, None, None) , (16396, 17, None, None) , (16396, 17, None, None) , (16396, 17, None, None) , 
			(16396, 17, None, None) , (16396, 17, None, None) , (16396, 17, None, None) , (16396, 17, None, None) , (16396, 17, None, None) , 
			(16396, 17, None, None) , (16396, 17, None, None) , (16396, 17, None, None) , (16396, 17, None, None) , (16396, 17, None, None) , 
			(16396, 17, None, None) , (16396, 17, None, None) , (16396, 17, None, None) , ], 1 , 1 , 4 , 18 , 324 , (3, 0, None, None) , 0 , )),
	(( u'ToggleShowAllReviewers' , ), 446, (446, (), [ ], 1 , 1 , 4 , 0 , 328 , (3, 0, None, None) , 64 , )),
	(( u'Thumbnails' , u'prop' , ), 37, (37, (), [ (16395, 10, None, None) , ], 1 , 2 , 4 , 0 , 332 , (3, 0, None, None) , 0 , )),
	(( u'Thumbnails' , u'prop' , ), 37, (37, (), [ (11, 1, None, None) , ], 1 , 4 , 4 , 0 , 336 , (3, 0, None, None) , 0 , )),
	(( u'ShowSourceDocuments' , u'prop' , ), 38, (38, (), [ (16387, 10, None, None) , ], 1 , 2 , 4 , 0 , 340 , (3, 0, None, None) , 0 , )),
	(( u'ShowSourceDocuments' , u'prop' , ), 38, (38, (), [ (3, 1, None, None) , ], 1 , 4 , 4 , 0 , 344 , (3, 0, None, None) , 0 , )),
	(( u'ToggleRibbon' , ), 447, (447, (), [ ], 1 , 1 , 4 , 0 , 348 , (3, 0, None, None) , 0 , )),
	(( u'Hwnd' , u'prop' , ), 39, (39, (), [ (16387, 10, None, None) , ], 1 , 2 , 4 , 0 , 352 , (3, 0, None, None) , 0 , )),
]

win32com.client.CLSIDToClass.RegisterCLSID( "{00020962-0000-0000-C000-000000000046}", Window )
