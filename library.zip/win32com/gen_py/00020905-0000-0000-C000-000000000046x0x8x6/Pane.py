# -*- coding: mbcs -*-
# Created by makepy.py version 0.5.01
# By python version 2.7.10 (default, May 23 2015, 09:40:32) [MSC v.1500 32 bit (Intel)]
# From type library '{00020905-0000-0000-C000-000000000046}'
# On Thu Jun 11 14:28:53 2015
'Microsoft Word 15.0 Object Library'
makepy_version = '0.5.01'
python_version = 0x2070af0

import win32com.client.CLSIDToClass, pythoncom, pywintypes
import win32com.client.util
from pywintypes import IID
from win32com.client import Dispatch

# The following 3 lines may need tweaking for the particular server
# Candidates are pythoncom.Missing, .Empty and .ArgNotFound
defaultNamedOptArg=pythoncom.Empty
defaultNamedNotOptArg=pythoncom.Empty
defaultUnnamedArg=pythoncom.Empty

CLSID = IID('{00020905-0000-0000-C000-000000000046}')
MajorVersion = 8
MinorVersion = 6
LibraryFlags = 8
LCID = 0x0

from win32com.client import DispatchBaseClass
class Pane(DispatchBaseClass):
	CLSID = IID('{00020960-0000-0000-C000-000000000046}')
	coclass_clsid = None

	def Activate(self):
		return self._oleobj_.InvokeTypes(100, LCID, 1, (24, 0), (),)

	def AutoScroll(self, Velocity=defaultNamedNotOptArg):
		return self._oleobj_.InvokeTypes(104, LCID, 1, (24, 0), ((3, 1),),Velocity
			)

	def Close(self):
		return self._oleobj_.InvokeTypes(101, LCID, 1, (24, 0), (),)

	def LargeScroll(self, Down=defaultNamedOptArg, Up=defaultNamedOptArg, ToRight=defaultNamedOptArg, ToLeft=defaultNamedOptArg):
		return self._oleobj_.InvokeTypes(102, LCID, 1, (24, 0), ((16396, 17), (16396, 17), (16396, 17), (16396, 17)),Down
			, Up, ToRight, ToLeft)

	def NewFrameset(self):
		return self._oleobj_.InvokeTypes(106, LCID, 1, (24, 0), (),)

	def PageScroll(self, Down=defaultNamedOptArg, Up=defaultNamedOptArg):
		return self._oleobj_.InvokeTypes(105, LCID, 1, (24, 0), ((16396, 17), (16396, 17)),Down
			, Up)

	def SmallScroll(self, Down=defaultNamedOptArg, Up=defaultNamedOptArg, ToRight=defaultNamedOptArg, ToLeft=defaultNamedOptArg):
		return self._oleobj_.InvokeTypes(103, LCID, 1, (24, 0), ((16396, 17), (16396, 17), (16396, 17), (16396, 17)),Down
			, Up, ToRight, ToLeft)

	def TOCInFrameset(self):
		return self._oleobj_.InvokeTypes(107, LCID, 1, (24, 0), (),)

	_prop_map_get_ = {
		# Method 'Application' returns object of type 'Application'
		"Application": (1000, 2, (13, 0), (), "Application", '{000209FF-0000-0000-C000-000000000046}'),
		"BrowseToWindow": (16, 2, (11, 0), (), "BrowseToWindow", None),
		"BrowseWidth": (17, 2, (3, 0), (), "BrowseWidth", None),
		"Creator": (1001, 2, (3, 0), (), "Creator", None),
		"DisplayRulers": (4, 2, (11, 0), (), "DisplayRulers", None),
		"DisplayVerticalRuler": (5, 2, (11, 0), (), "DisplayVerticalRuler", None),
		# Method 'Document' returns object of type 'Document'
		"Document": (1, 2, (13, 0), (), "Document", '{00020906-0000-0000-C000-000000000046}'),
		# Method 'Frameset' returns object of type 'Frameset'
		"Frameset": (18, 2, (9, 0), (), "Frameset", '{000209E2-0000-0000-C000-000000000046}'),
		"HorizontalPercentScrolled": (13, 2, (3, 0), (), "HorizontalPercentScrolled", None),
		"Index": (9, 2, (3, 0), (), "Index", None),
		"MinimumFontSize": (15, 2, (3, 0), (), "MinimumFontSize", None),
		# Method 'Next' returns object of type 'Pane'
		"Next": (11, 2, (9, 0), (), "Next", '{00020960-0000-0000-C000-000000000046}'),
		# Method 'Pages' returns object of type 'Pages'
		"Pages": (19, 2, (9, 0), (), "Pages", '{91807402-6C6F-47CD-B8FA-C42FEE8EE924}'),
		"Parent": (1002, 2, (9, 0), (), "Parent", None),
		# Method 'Previous' returns object of type 'Pane'
		"Previous": (12, 2, (9, 0), (), "Previous", '{00020960-0000-0000-C000-000000000046}'),
		# Method 'Selection' returns object of type 'Selection'
		"Selection": (3, 2, (9, 0), (), "Selection", '{00020975-0000-0000-C000-000000000046}'),
		"VerticalPercentScrolled": (14, 2, (3, 0), (), "VerticalPercentScrolled", None),
		# Method 'View' returns object of type 'View'
		"View": (10, 2, (9, 0), (), "View", '{000209A5-0000-0000-C000-000000000046}'),
		# Method 'Zooms' returns object of type 'Zooms'
		"Zooms": (7, 2, (9, 0), (), "Zooms", '{000209A7-0000-0000-C000-000000000046}'),
	}
	_prop_map_put_ = {
		"BrowseToWindow": ((16, LCID, 4, 0),()),
		"DisplayRulers": ((4, LCID, 4, 0),()),
		"DisplayVerticalRuler": ((5, LCID, 4, 0),()),
		"HorizontalPercentScrolled": ((13, LCID, 4, 0),()),
		"MinimumFontSize": ((15, LCID, 4, 0),()),
		"VerticalPercentScrolled": ((14, LCID, 4, 0),()),
	}
	def __iter__(self):
		"Return a Python iterator for this object"
		try:
			ob = self._oleobj_.InvokeTypes(-4,LCID,3,(13, 10),())
		except pythoncom.error:
			raise TypeError("This object does not support enumeration")
		return win32com.client.util.Iterator(ob, None)

win32com.client.CLSIDToClass.RegisterCLSID( "{00020960-0000-0000-C000-000000000046}", Pane )
# -*- coding: mbcs -*-
# Created by makepy.py version 0.5.01
# By python version 2.7.10 (default, May 23 2015, 09:40:32) [MSC v.1500 32 bit (Intel)]
# From type library '{00020905-0000-0000-C000-000000000046}'
# On Thu Jun 11 14:28:53 2015
'Microsoft Word 15.0 Object Library'
makepy_version = '0.5.01'
python_version = 0x2070af0

import win32com.client.CLSIDToClass, pythoncom, pywintypes
import win32com.client.util
from pywintypes import IID
from win32com.client import Dispatch

# The following 3 lines may need tweaking for the particular server
# Candidates are pythoncom.Missing, .Empty and .ArgNotFound
defaultNamedOptArg=pythoncom.Empty
defaultNamedNotOptArg=pythoncom.Empty
defaultUnnamedArg=pythoncom.Empty

CLSID = IID('{00020905-0000-0000-C000-000000000046}')
MajorVersion = 8
MinorVersion = 6
LibraryFlags = 8
LCID = 0x0

Pane_vtables_dispatch_ = 1
Pane_vtables_ = [
	(( u'Application' , u'prop' , ), 1000, (1000, (), [ (16397, 10, None, "IID('{000209FF-0000-0000-C000-000000000046}')") , ], 1 , 2 , 4 , 0 , 28 , (3, 0, None, None) , 0 , )),
	(( u'Creator' , u'prop' , ), 1001, (1001, (), [ (16387, 10, None, None) , ], 1 , 2 , 4 , 0 , 32 , (3, 0, None, None) , 0 , )),
	(( u'Parent' , u'prop' , ), 1002, (1002, (), [ (16393, 10, None, None) , ], 1 , 2 , 4 , 0 , 36 , (3, 0, None, None) , 0 , )),
	(( u'Document' , u'prop' , ), 1, (1, (), [ (16397, 10, None, "IID('{00020906-0000-0000-C000-000000000046}')") , ], 1 , 2 , 4 , 0 , 40 , (3, 0, None, None) , 0 , )),
	(( u'Selection' , u'prop' , ), 3, (3, (), [ (16393, 10, None, "IID('{00020975-0000-0000-C000-000000000046}')") , ], 1 , 2 , 4 , 0 , 44 , (3, 0, None, None) , 0 , )),
	(( u'DisplayRulers' , u'prop' , ), 4, (4, (), [ (16395, 10, None, None) , ], 1 , 2 , 4 , 0 , 48 , (3, 0, None, None) , 0 , )),
	(( u'DisplayRulers' , u'prop' , ), 4, (4, (), [ (11, 1, None, None) , ], 1 , 4 , 4 , 0 , 52 , (3, 0, None, None) , 0 , )),
	(( u'DisplayVerticalRuler' , u'prop' , ), 5, (5, (), [ (16395, 10, None, None) , ], 1 , 2 , 4 , 0 , 56 , (3, 0, None, None) , 0 , )),
	(( u'DisplayVerticalRuler' , u'prop' , ), 5, (5, (), [ (11, 1, None, None) , ], 1 , 4 , 4 , 0 , 60 , (3, 0, None, None) , 0 , )),
	(( u'Zooms' , u'prop' , ), 7, (7, (), [ (16393, 10, None, "IID('{000209A7-0000-0000-C000-000000000046}')") , ], 1 , 2 , 4 , 0 , 64 , (3, 0, None, None) , 0 , )),
	(( u'Index' , u'prop' , ), 9, (9, (), [ (16387, 10, None, None) , ], 1 , 2 , 4 , 0 , 68 , (3, 0, None, None) , 0 , )),
	(( u'View' , u'prop' , ), 10, (10, (), [ (16393, 10, None, "IID('{000209A5-0000-0000-C000-000000000046}')") , ], 1 , 2 , 4 , 0 , 72 , (3, 0, None, None) , 0 , )),
	(( u'Next' , u'prop' , ), 11, (11, (), [ (16393, 10, None, "IID('{00020960-0000-0000-C000-000000000046}')") , ], 1 , 2 , 4 , 0 , 76 , (3, 0, None, None) , 0 , )),
	(( u'Previous' , u'prop' , ), 12, (12, (), [ (16393, 10, None, "IID('{00020960-0000-0000-C000-000000000046}')") , ], 1 , 2 , 4 , 0 , 80 , (3, 0, None, None) , 0 , )),
	(( u'HorizontalPercentScrolled' , u'prop' , ), 13, (13, (), [ (16387, 10, None, None) , ], 1 , 2 , 4 , 0 , 84 , (3, 0, None, None) , 0 , )),
	(( u'HorizontalPercentScrolled' , u'prop' , ), 13, (13, (), [ (3, 1, None, None) , ], 1 , 4 , 4 , 0 , 88 , (3, 0, None, None) , 0 , )),
	(( u'VerticalPercentScrolled' , u'prop' , ), 14, (14, (), [ (16387, 10, None, None) , ], 1 , 2 , 4 , 0 , 92 , (3, 0, None, None) , 0 , )),
	(( u'VerticalPercentScrolled' , u'prop' , ), 14, (14, (), [ (3, 1, None, None) , ], 1 , 4 , 4 , 0 , 96 , (3, 0, None, None) , 0 , )),
	(( u'MinimumFontSize' , u'prop' , ), 15, (15, (), [ (16387, 10, None, None) , ], 1 , 2 , 4 , 0 , 100 , (3, 0, None, None) , 0 , )),
	(( u'MinimumFontSize' , u'prop' , ), 15, (15, (), [ (3, 1, None, None) , ], 1 , 4 , 4 , 0 , 104 , (3, 0, None, None) , 0 , )),
	(( u'BrowseToWindow' , u'prop' , ), 16, (16, (), [ (16395, 10, None, None) , ], 1 , 2 , 4 , 0 , 108 , (3, 0, None, None) , 64 , )),
	(( u'BrowseToWindow' , u'prop' , ), 16, (16, (), [ (11, 1, None, None) , ], 1 , 4 , 4 , 0 , 112 , (3, 0, None, None) , 64 , )),
	(( u'BrowseWidth' , u'prop' , ), 17, (17, (), [ (16387, 10, None, None) , ], 1 , 2 , 4 , 0 , 116 , (3, 0, None, None) , 0 , )),
	(( u'Activate' , ), 100, (100, (), [ ], 1 , 1 , 4 , 0 , 120 , (3, 0, None, None) , 0 , )),
	(( u'Close' , ), 101, (101, (), [ ], 1 , 1 , 4 , 0 , 124 , (3, 0, None, None) , 0 , )),
	(( u'LargeScroll' , u'Down' , u'Up' , u'ToRight' , u'ToLeft' , 
			), 102, (102, (), [ (16396, 17, None, None) , (16396, 17, None, None) , (16396, 17, None, None) , (16396, 17, None, None) , ], 1 , 1 , 4 , 4 , 128 , (3, 0, None, None) , 0 , )),
	(( u'SmallScroll' , u'Down' , u'Up' , u'ToRight' , u'ToLeft' , 
			), 103, (103, (), [ (16396, 17, None, None) , (16396, 17, None, None) , (16396, 17, None, None) , (16396, 17, None, None) , ], 1 , 1 , 4 , 4 , 132 , (3, 0, None, None) , 0 , )),
	(( u'AutoScroll' , u'Velocity' , ), 104, (104, (), [ (3, 1, None, None) , ], 1 , 1 , 4 , 0 , 136 , (3, 0, None, None) , 0 , )),
	(( u'PageScroll' , u'Down' , u'Up' , ), 105, (105, (), [ (16396, 17, None, None) , 
			(16396, 17, None, None) , ], 1 , 1 , 4 , 2 , 140 , (3, 0, None, None) , 0 , )),
	(( u'NewFrameset' , ), 106, (106, (), [ ], 1 , 1 , 4 , 0 , 144 , (3, 0, None, None) , 0 , )),
	(( u'TOCInFrameset' , ), 107, (107, (), [ ], 1 , 1 , 4 , 0 , 148 , (3, 0, None, None) , 0 , )),
	(( u'Frameset' , u'prop' , ), 18, (18, (), [ (16393, 10, None, "IID('{000209E2-0000-0000-C000-000000000046}')") , ], 1 , 2 , 4 , 0 , 152 , (3, 0, None, None) , 0 , )),
	(( u'Pages' , u'prop' , ), 19, (19, (), [ (16393, 10, None, "IID('{91807402-6C6F-47CD-B8FA-C42FEE8EE924}')") , ], 1 , 2 , 4 , 0 , 156 , (3, 0, None, None) , 0 , )),
]

win32com.client.CLSIDToClass.RegisterCLSID( "{00020960-0000-0000-C000-000000000046}", Pane )
