# -*- coding: mbcs -*-
# Created by makepy.py version 0.5.01
# By python version 2.7.10 (default, May 23 2015, 09:40:32) [MSC v.1500 32 bit (Intel)]
# From type library '{00020813-0000-0000-C000-000000000046}'
# On Thu Jun 11 17:00:47 2015
'Microsoft Excel 15.0 Object Library'
makepy_version = '0.5.01'
python_version = 0x2070af0

import win32com.client.CLSIDToClass, pythoncom, pywintypes
import win32com.client.util
from pywintypes import IID
from win32com.client import Dispatch

# The following 3 lines may need tweaking for the particular server
# Candidates are pythoncom.Missing, .Empty and .ArgNotFound
defaultNamedOptArg=pythoncom.Empty
defaultNamedNotOptArg=pythoncom.Empty
defaultUnnamedArg=pythoncom.Empty

CLSID = IID('{00020813-0000-0000-C000-000000000046}')
MajorVersion = 1
MinorVersion = 8
LibraryFlags = 8
LCID = 0x0

from win32com.client import DispatchBaseClass
class Workbooks(DispatchBaseClass):
	CLSID = IID('{000208DB-0000-0000-C000-000000000046}')
	coclass_clsid = None

	# Result is of type Workbook
	def Add(self, Template=defaultNamedOptArg):
		ret = self._oleobj_.InvokeTypes(181, LCID, 1, (13, 0), ((12, 17),),Template
			)
		if ret is not None:
			# See if this IUnknown is really an IDispatch
			try:
				ret = ret.QueryInterface(pythoncom.IID_IDispatch)
			except pythoncom.error:
				return ret
			ret = Dispatch(ret, u'Add', '{00020819-0000-0000-C000-000000000046}')
		return ret

	def CanCheckOut(self, Filename=defaultNamedNotOptArg):
		return self._oleobj_.InvokeTypes(2070, LCID, 1, (11, 0), ((8, 1),),Filename
			)

	def CheckOut(self, Filename=defaultNamedNotOptArg):
		return self._oleobj_.InvokeTypes(2069, LCID, 1, (24, 0), ((8, 1),),Filename
			)

	def Close(self):
		return self._oleobj_.InvokeTypes(277, LCID, 1, (24, 0), (),)

	# Result is of type Workbook
	# The method Item is actually a property, but must be used as a method to correctly pass the arguments
	def Item(self, Index=defaultNamedNotOptArg):
		ret = self._oleobj_.InvokeTypes(170, LCID, 2, (13, 0), ((12, 1),),Index
			)
		if ret is not None:
			# See if this IUnknown is really an IDispatch
			try:
				ret = ret.QueryInterface(pythoncom.IID_IDispatch)
			except pythoncom.error:
				return ret
			ret = Dispatch(ret, u'Item', '{00020819-0000-0000-C000-000000000046}')
		return ret

	# Result is of type Workbook
	def Open(self, Filename=defaultNamedNotOptArg, UpdateLinks=defaultNamedOptArg, ReadOnly=defaultNamedOptArg, Format=defaultNamedOptArg
			, Password=defaultNamedOptArg, WriteResPassword=defaultNamedOptArg, IgnoreReadOnlyRecommended=defaultNamedOptArg, Origin=defaultNamedOptArg, Delimiter=defaultNamedOptArg
			, Editable=defaultNamedOptArg, Notify=defaultNamedOptArg, Converter=defaultNamedOptArg, AddToMru=defaultNamedOptArg, Local=defaultNamedOptArg
			, CorruptLoad=defaultNamedOptArg):
		ret = self._oleobj_.InvokeTypes(1923, LCID, 1, (13, 0), ((8, 1), (12, 17), (12, 17), (12, 17), (12, 17), (12, 17), (12, 17), (12, 17), (12, 17), (12, 17), (12, 17), (12, 17), (12, 17), (12, 17), (12, 17)),Filename
			, UpdateLinks, ReadOnly, Format, Password, WriteResPassword
			, IgnoreReadOnlyRecommended, Origin, Delimiter, Editable, Notify
			, Converter, AddToMru, Local, CorruptLoad)
		if ret is not None:
			# See if this IUnknown is really an IDispatch
			try:
				ret = ret.QueryInterface(pythoncom.IID_IDispatch)
			except pythoncom.error:
				return ret
			ret = Dispatch(ret, u'Open', '{00020819-0000-0000-C000-000000000046}')
		return ret

	# Result is of type Workbook
	def OpenDatabase(self, Filename=defaultNamedNotOptArg, CommandText=defaultNamedOptArg, CommandType=defaultNamedOptArg, BackgroundQuery=defaultNamedOptArg
			, ImportDataAs=defaultNamedOptArg):
		ret = self._oleobj_.InvokeTypes(2067, LCID, 1, (13, 0), ((8, 1), (12, 17), (12, 17), (12, 17), (12, 17)),Filename
			, CommandText, CommandType, BackgroundQuery, ImportDataAs)
		if ret is not None:
			# See if this IUnknown is really an IDispatch
			try:
				ret = ret.QueryInterface(pythoncom.IID_IDispatch)
			except pythoncom.error:
				return ret
			ret = Dispatch(ret, u'OpenDatabase', '{00020819-0000-0000-C000-000000000046}')
		return ret

	def OpenText(self, Filename=defaultNamedNotOptArg, Origin=defaultNamedNotOptArg, StartRow=defaultNamedNotOptArg, DataType=defaultNamedNotOptArg
			, TextQualifier=1, ConsecutiveDelimiter=defaultNamedOptArg, Tab=defaultNamedOptArg, Semicolon=defaultNamedOptArg, Comma=defaultNamedOptArg
			, Space=defaultNamedOptArg, Other=defaultNamedOptArg, OtherChar=defaultNamedOptArg, FieldInfo=defaultNamedOptArg, TextVisualLayout=defaultNamedOptArg
			, DecimalSeparator=defaultNamedOptArg, ThousandsSeparator=defaultNamedOptArg, TrailingMinusNumbers=defaultNamedOptArg, Local=defaultNamedOptArg):
		return self._oleobj_.InvokeTypes(1924, LCID, 1, (24, 0), ((8, 1), (12, 17), (12, 17), (12, 17), (3, 49), (12, 17), (12, 17), (12, 17), (12, 17), (12, 17), (12, 17), (12, 17), (12, 17), (12, 17), (12, 17), (12, 17), (12, 17), (12, 17)),Filename
			, Origin, StartRow, DataType, TextQualifier, ConsecutiveDelimiter
			, Tab, Semicolon, Comma, Space, Other
			, OtherChar, FieldInfo, TextVisualLayout, DecimalSeparator, ThousandsSeparator
			, TrailingMinusNumbers, Local)

	# Result is of type Workbook
	def OpenXML(self, Filename=defaultNamedNotOptArg, Stylesheets=defaultNamedOptArg, LoadOption=defaultNamedOptArg):
		ret = self._oleobj_.InvokeTypes(2280, LCID, 1, (13, 0), ((8, 1), (12, 17), (12, 17)),Filename
			, Stylesheets, LoadOption)
		if ret is not None:
			# See if this IUnknown is really an IDispatch
			try:
				ret = ret.QueryInterface(pythoncom.IID_IDispatch)
			except pythoncom.error:
				return ret
			ret = Dispatch(ret, u'OpenXML', '{00020819-0000-0000-C000-000000000046}')
		return ret

	# Result is of type Workbook
	# The method _Default is actually a property, but must be used as a method to correctly pass the arguments
	def _Default(self, Index=defaultNamedNotOptArg):
		ret = self._oleobj_.InvokeTypes(0, LCID, 2, (13, 0), ((12, 1),),Index
			)
		if ret is not None:
			# See if this IUnknown is really an IDispatch
			try:
				ret = ret.QueryInterface(pythoncom.IID_IDispatch)
			except pythoncom.error:
				return ret
			ret = Dispatch(ret, u'_Default', '{00020819-0000-0000-C000-000000000046}')
		return ret

	# Result is of type Workbook
	def _Open(self, Filename=defaultNamedNotOptArg, UpdateLinks=defaultNamedOptArg, ReadOnly=defaultNamedOptArg, Format=defaultNamedOptArg
			, Password=defaultNamedOptArg, WriteResPassword=defaultNamedOptArg, IgnoreReadOnlyRecommended=defaultNamedOptArg, Origin=defaultNamedOptArg, Delimiter=defaultNamedOptArg
			, Editable=defaultNamedOptArg, Notify=defaultNamedOptArg, Converter=defaultNamedOptArg, AddToMru=defaultNamedOptArg):
		ret = self._oleobj_.InvokeTypes(682, LCID, 1, (13, 0), ((8, 1), (12, 17), (12, 17), (12, 17), (12, 17), (12, 17), (12, 17), (12, 17), (12, 17), (12, 17), (12, 17), (12, 17), (12, 17)),Filename
			, UpdateLinks, ReadOnly, Format, Password, WriteResPassword
			, IgnoreReadOnlyRecommended, Origin, Delimiter, Editable, Notify
			, Converter, AddToMru)
		if ret is not None:
			# See if this IUnknown is really an IDispatch
			try:
				ret = ret.QueryInterface(pythoncom.IID_IDispatch)
			except pythoncom.error:
				return ret
			ret = Dispatch(ret, u'_Open', '{00020819-0000-0000-C000-000000000046}')
		return ret

	def _OpenText(self, Filename=defaultNamedNotOptArg, Origin=defaultNamedNotOptArg, StartRow=defaultNamedNotOptArg, DataType=defaultNamedNotOptArg
			, TextQualifier=1, ConsecutiveDelimiter=defaultNamedOptArg, Tab=defaultNamedOptArg, Semicolon=defaultNamedOptArg, Comma=defaultNamedOptArg
			, Space=defaultNamedOptArg, Other=defaultNamedOptArg, OtherChar=defaultNamedOptArg, FieldInfo=defaultNamedOptArg, TextVisualLayout=defaultNamedOptArg
			, DecimalSeparator=defaultNamedOptArg, ThousandsSeparator=defaultNamedOptArg):
		return self._oleobj_.InvokeTypes(1773, LCID, 1, (24, 0), ((8, 1), (12, 17), (12, 17), (12, 17), (3, 49), (12, 17), (12, 17), (12, 17), (12, 17), (12, 17), (12, 17), (12, 17), (12, 17), (12, 17), (12, 17), (12, 17)),Filename
			, Origin, StartRow, DataType, TextQualifier, ConsecutiveDelimiter
			, Tab, Semicolon, Comma, Space, Other
			, OtherChar, FieldInfo, TextVisualLayout, DecimalSeparator, ThousandsSeparator
			)

	# Result is of type Workbook
	def _OpenXML(self, Filename=defaultNamedNotOptArg, Stylesheets=defaultNamedOptArg):
		ret = self._oleobj_.InvokeTypes(2071, LCID, 1, (13, 0), ((8, 1), (12, 17)),Filename
			, Stylesheets)
		if ret is not None:
			# See if this IUnknown is really an IDispatch
			try:
				ret = ret.QueryInterface(pythoncom.IID_IDispatch)
			except pythoncom.error:
				return ret
			ret = Dispatch(ret, u'_OpenXML', '{00020819-0000-0000-C000-000000000046}')
		return ret

	def _OpenText_(self, Filename=defaultNamedNotOptArg, Origin=defaultNamedNotOptArg, StartRow=defaultNamedNotOptArg, DataType=defaultNamedNotOptArg
			, TextQualifier=1, ConsecutiveDelimiter=defaultNamedOptArg, Tab=defaultNamedOptArg, Semicolon=defaultNamedOptArg, Comma=defaultNamedOptArg
			, Space=defaultNamedOptArg, Other=defaultNamedOptArg, OtherChar=defaultNamedOptArg, FieldInfo=defaultNamedOptArg, TextVisualLayout=defaultNamedOptArg):
		return self._oleobj_.InvokeTypes(683, LCID, 1, (24, 0), ((8, 1), (12, 17), (12, 17), (12, 17), (3, 49), (12, 17), (12, 17), (12, 17), (12, 17), (12, 17), (12, 17), (12, 17), (12, 17), (12, 17)),Filename
			, Origin, StartRow, DataType, TextQualifier, ConsecutiveDelimiter
			, Tab, Semicolon, Comma, Space, Other
			, OtherChar, FieldInfo, TextVisualLayout)

	_prop_map_get_ = {
		# Method 'Application' returns object of type 'Application'
		"Application": (148, 2, (13, 0), (), "Application", '{00024500-0000-0000-C000-000000000046}'),
		"Count": (118, 2, (3, 0), (), "Count", None),
		"Creator": (149, 2, (3, 0), (), "Creator", None),
		"Parent": (150, 2, (9, 0), (), "Parent", None),
	}
	_prop_map_put_ = {
	}
	# Default method for this class is '_Default'
	def __call__(self, Index=defaultNamedNotOptArg):
		ret = self._oleobj_.InvokeTypes(0, LCID, 2, (13, 0), ((12, 1),),Index
			)
		if ret is not None:
			# See if this IUnknown is really an IDispatch
			try:
				ret = ret.QueryInterface(pythoncom.IID_IDispatch)
			except pythoncom.error:
				return ret
			ret = Dispatch(ret, '__call__', '{00020819-0000-0000-C000-000000000046}')
		return ret

	def __unicode__(self, *args):
		try:
			return unicode(self.__call__(*args))
		except pythoncom.com_error:
			return repr(self)
	def __str__(self, *args):
		return str(self.__unicode__(*args))
	def __int__(self, *args):
		return int(self.__call__(*args))
	def __iter__(self):
		"Return a Python iterator for this object"
		try:
			ob = self._oleobj_.InvokeTypes(-4,LCID,2,(13, 10),())
		except pythoncom.error:
			raise TypeError("This object does not support enumeration")
		return win32com.client.util.Iterator(ob, '{00020819-0000-0000-C000-000000000046}')
	#This class has Item property/method which allows indexed access with the object[key] syntax.
	#Some objects will accept a string or other type of key in addition to integers.
	#Note that many Office objects do not use zero-based indexing.
	def __getitem__(self, key):
		return self._get_good_object_(self._oleobj_.Invoke(*(170, LCID, 2, 1, key)), "Item", '{00020819-0000-0000-C000-000000000046}')
	#This class has Count() property - allow len(ob) to provide this
	def __len__(self):
		return self._ApplyTypes_(*(118, 2, (3, 0), (), "Count", None))
	#This class has a __len__ - this is needed so 'if object:' always returns TRUE.
	def __nonzero__(self):
		return True

win32com.client.CLSIDToClass.RegisterCLSID( "{000208DB-0000-0000-C000-000000000046}", Workbooks )
# -*- coding: mbcs -*-
# Created by makepy.py version 0.5.01
# By python version 2.7.10 (default, May 23 2015, 09:40:32) [MSC v.1500 32 bit (Intel)]
# From type library '{00020813-0000-0000-C000-000000000046}'
# On Thu Jun 11 17:00:47 2015
'Microsoft Excel 15.0 Object Library'
makepy_version = '0.5.01'
python_version = 0x2070af0

import win32com.client.CLSIDToClass, pythoncom, pywintypes
import win32com.client.util
from pywintypes import IID
from win32com.client import Dispatch

# The following 3 lines may need tweaking for the particular server
# Candidates are pythoncom.Missing, .Empty and .ArgNotFound
defaultNamedOptArg=pythoncom.Empty
defaultNamedNotOptArg=pythoncom.Empty
defaultUnnamedArg=pythoncom.Empty

CLSID = IID('{00020813-0000-0000-C000-000000000046}')
MajorVersion = 1
MinorVersion = 8
LibraryFlags = 8
LCID = 0x0

Workbooks_vtables_dispatch_ = 1
Workbooks_vtables_ = [
	(( u'Application' , u'RHS' , ), 148, (148, (), [ (16397, 10, None, "IID('{00024500-0000-0000-C000-000000000046}')") , ], 1 , 2 , 4 , 0 , 28 , (3, 0, None, None) , 0 , )),
	(( u'Creator' , u'RHS' , ), 149, (149, (), [ (16387, 10, None, None) , ], 1 , 2 , 4 , 0 , 32 , (3, 0, None, None) , 0 , )),
	(( u'Parent' , u'RHS' , ), 150, (150, (), [ (16393, 10, None, None) , ], 1 , 2 , 4 , 0 , 36 , (3, 0, None, None) , 0 , )),
	(( u'Add' , u'Template' , u'lcid' , u'RHS' , ), 181, (181, (), [ 
			(12, 17, None, None) , (3, 5, None, None) , (16397, 10, None, "IID('{00020819-0000-0000-C000-000000000046}')") , ], 1 , 1 , 4 , 1 , 40 , (3, 0, None, None) , 0 , )),
	(( u'Close' , u'lcid' , ), 277, (277, (), [ (3, 5, None, None) , ], 1 , 1 , 4 , 0 , 44 , (3, 0, None, None) , 0 , )),
	(( u'Count' , u'RHS' , ), 118, (118, (), [ (16387, 10, None, None) , ], 1 , 2 , 4 , 0 , 48 , (3, 0, None, None) , 0 , )),
	(( u'Item' , u'Index' , u'RHS' , ), 170, (170, (), [ (12, 1, None, None) , 
			(16397, 10, None, "IID('{00020819-0000-0000-C000-000000000046}')") , ], 1 , 2 , 4 , 0 , 52 , (3, 0, None, None) , 0 , )),
	(( u'_NewEnum' , u'RHS' , ), -4, (-4, (), [ (16397, 10, None, None) , ], 1 , 2 , 4 , 0 , 56 , (3, 0, None, None) , 1024 , )),
	(( u'_Open' , u'Filename' , u'UpdateLinks' , u'ReadOnly' , u'Format' , 
			u'Password' , u'WriteResPassword' , u'IgnoreReadOnlyRecommended' , u'Origin' , u'Delimiter' , 
			u'Editable' , u'Notify' , u'Converter' , u'AddToMru' , u'lcid' , 
			u'RHS' , ), 682, (682, (), [ (8, 1, None, None) , (12, 17, None, None) , (12, 17, None, None) , 
			(12, 17, None, None) , (12, 17, None, None) , (12, 17, None, None) , (12, 17, None, None) , (12, 17, None, None) , 
			(12, 17, None, None) , (12, 17, None, None) , (12, 17, None, None) , (12, 17, None, None) , (12, 17, None, None) , 
			(3, 5, None, None) , (16397, 10, None, "IID('{00020819-0000-0000-C000-000000000046}')") , ], 1 , 1 , 4 , 12 , 60 , (3, 0, None, None) , 1088 , )),
	(( u'__OpenText' , u'Filename' , u'Origin' , u'StartRow' , u'DataType' , 
			u'TextQualifier' , u'ConsecutiveDelimiter' , u'Tab' , u'Semicolon' , u'Comma' , 
			u'Space' , u'Other' , u'OtherChar' , u'FieldInfo' , u'TextVisualLayout' , 
			u'lcid' , ), 683, (683, (), [ (8, 1, None, None) , (12, 17, None, None) , (12, 17, None, None) , 
			(12, 17, None, None) , (3, 49, '1', None) , (12, 17, None, None) , (12, 17, None, None) , (12, 17, None, None) , 
			(12, 17, None, None) , (12, 17, None, None) , (12, 17, None, None) , (12, 17, None, None) , (12, 17, None, None) , 
			(12, 17, None, None) , (3, 5, None, None) , ], 1 , 1 , 4 , 9 , 64 , (3, 0, None, None) , 1088 , )),
	(( u'_Default' , u'Index' , u'RHS' , ), 0, (0, (), [ (12, 1, None, None) , 
			(16397, 10, None, "IID('{00020819-0000-0000-C000-000000000046}')") , ], 1 , 2 , 4 , 0 , 68 , (3, 0, None, None) , 1024 , )),
	(( u'_OpenText' , u'Filename' , u'Origin' , u'StartRow' , u'DataType' , 
			u'TextQualifier' , u'ConsecutiveDelimiter' , u'Tab' , u'Semicolon' , u'Comma' , 
			u'Space' , u'Other' , u'OtherChar' , u'FieldInfo' , u'TextVisualLayout' , 
			u'DecimalSeparator' , u'ThousandsSeparator' , u'lcid' , ), 1773, (1773, (), [ (8, 1, None, None) , 
			(12, 17, None, None) , (12, 17, None, None) , (12, 17, None, None) , (3, 49, '1', None) , (12, 17, None, None) , 
			(12, 17, None, None) , (12, 17, None, None) , (12, 17, None, None) , (12, 17, None, None) , (12, 17, None, None) , 
			(12, 17, None, None) , (12, 17, None, None) , (12, 17, None, None) , (12, 17, None, None) , (12, 17, None, None) , 
			(3, 5, None, None) , ], 1 , 1 , 4 , 11 , 72 , (3, 0, None, None) , 1088 , )),
	(( u'Open' , u'Filename' , u'UpdateLinks' , u'ReadOnly' , u'Format' , 
			u'Password' , u'WriteResPassword' , u'IgnoreReadOnlyRecommended' , u'Origin' , u'Delimiter' , 
			u'Editable' , u'Notify' , u'Converter' , u'AddToMru' , u'Local' , 
			u'CorruptLoad' , u'lcid' , u'RHS' , ), 1923, (1923, (), [ (8, 1, None, None) , 
			(12, 17, None, None) , (12, 17, None, None) , (12, 17, None, None) , (12, 17, None, None) , (12, 17, None, None) , 
			(12, 17, None, None) , (12, 17, None, None) , (12, 17, None, None) , (12, 17, None, None) , (12, 17, None, None) , 
			(12, 17, None, None) , (12, 17, None, None) , (12, 17, None, None) , (12, 17, None, None) , (3, 5, None, None) , 
			(16397, 10, None, "IID('{00020819-0000-0000-C000-000000000046}')") , ], 1 , 1 , 4 , 14 , 76 , (3, 0, None, None) , 0 , )),
	(( u'OpenText' , u'Filename' , u'Origin' , u'StartRow' , u'DataType' , 
			u'TextQualifier' , u'ConsecutiveDelimiter' , u'Tab' , u'Semicolon' , u'Comma' , 
			u'Space' , u'Other' , u'OtherChar' , u'FieldInfo' , u'TextVisualLayout' , 
			u'DecimalSeparator' , u'ThousandsSeparator' , u'TrailingMinusNumbers' , u'Local' , u'lcid' , 
			), 1924, (1924, (), [ (8, 1, None, None) , (12, 17, None, None) , (12, 17, None, None) , (12, 17, None, None) , 
			(3, 49, '1', None) , (12, 17, None, None) , (12, 17, None, None) , (12, 17, None, None) , (12, 17, None, None) , 
			(12, 17, None, None) , (12, 17, None, None) , (12, 17, None, None) , (12, 17, None, None) , (12, 17, None, None) , 
			(12, 17, None, None) , (12, 17, None, None) , (12, 17, None, None) , (12, 17, None, None) , (3, 5, None, None) , ], 1 , 1 , 4 , 13 , 80 , (3, 0, None, None) , 0 , )),
	(( u'OpenDatabase' , u'Filename' , u'CommandText' , u'CommandType' , u'BackgroundQuery' , 
			u'ImportDataAs' , u'RHS' , ), 2067, (2067, (), [ (8, 1, None, None) , (12, 17, None, None) , 
			(12, 17, None, None) , (12, 17, None, None) , (12, 17, None, None) , (16397, 10, None, "IID('{00020819-0000-0000-C000-000000000046}')") , ], 1 , 1 , 4 , 4 , 84 , (3, 0, None, None) , 0 , )),
	(( u'CheckOut' , u'Filename' , ), 2069, (2069, (), [ (8, 1, None, None) , ], 1 , 1 , 4 , 0 , 88 , (3, 0, None, None) , 0 , )),
	(( u'CanCheckOut' , u'Filename' , u'RHS' , ), 2070, (2070, (), [ (8, 1, None, None) , 
			(16395, 10, None, None) , ], 1 , 1 , 4 , 0 , 92 , (3, 0, None, None) , 0 , )),
	(( u'_OpenXML' , u'Filename' , u'Stylesheets' , u'RHS' , ), 2071, (2071, (), [ 
			(8, 1, None, None) , (12, 17, None, None) , (16397, 10, None, "IID('{00020819-0000-0000-C000-000000000046}')") , ], 1 , 1 , 4 , 1 , 96 , (3, 0, None, None) , 1088 , )),
	(( u'OpenXML' , u'Filename' , u'Stylesheets' , u'LoadOption' , u'RHS' , 
			), 2280, (2280, (), [ (8, 1, None, None) , (12, 17, None, None) , (12, 17, None, None) , (16397, 10, None, "IID('{00020819-0000-0000-C000-000000000046}')") , ], 1 , 1 , 4 , 2 , 100 , (3, 0, None, None) , 0 , )),
]

win32com.client.CLSIDToClass.RegisterCLSID( "{000208DB-0000-0000-C000-000000000046}", Workbooks )
