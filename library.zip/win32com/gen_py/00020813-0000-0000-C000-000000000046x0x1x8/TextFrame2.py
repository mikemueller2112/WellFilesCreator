# -*- coding: mbcs -*-
# Created by makepy.py version 0.5.01
# By python version 2.7.10 (default, May 23 2015, 09:40:32) [MSC v.1500 32 bit (Intel)]
# From type library '{00020813-0000-0000-C000-000000000046}'
# On Thu Jun 11 17:00:48 2015
'Microsoft Excel 15.0 Object Library'
makepy_version = '0.5.01'
python_version = 0x2070af0

import win32com.client.CLSIDToClass, pythoncom, pywintypes
import win32com.client.util
from pywintypes import IID
from win32com.client import Dispatch

# The following 3 lines may need tweaking for the particular server
# Candidates are pythoncom.Missing, .Empty and .ArgNotFound
defaultNamedOptArg=pythoncom.Empty
defaultNamedNotOptArg=pythoncom.Empty
defaultUnnamedArg=pythoncom.Empty

CLSID = IID('{00020813-0000-0000-C000-000000000046}')
MajorVersion = 1
MinorVersion = 8
LibraryFlags = 8
LCID = 0x0

from win32com.client import DispatchBaseClass
class TextFrame2(DispatchBaseClass):
	CLSID = IID('{000C0398-0000-0000-C000-000000000046}')
	coclass_clsid = None

	def DeleteText(self):
		return self._oleobj_.InvokeTypes(117, LCID, 1, (24, 0), (),)

	_prop_map_get_ = {
		"Application": (1610743808, 2, (9, 0), (), "Application", None),
		"AutoSize": (111, 2, (3, 0), (), "AutoSize", None),
		# Method 'Column' returns object of type 'TextColumn2'
		"Column": (115, 2, (9, 0), (), "Column", '{000C03B2-0000-0000-C000-000000000046}'),
		"Creator": (1610743809, 2, (3, 0), (), "Creator", None),
		"HasText": (113, 2, (3, 0), (), "HasText", None),
		"HorizontalAnchor": (105, 2, (3, 0), (), "HorizontalAnchor", None),
		"MarginBottom": (100, 2, (4, 0), (), "MarginBottom", None),
		"MarginLeft": (101, 2, (4, 0), (), "MarginLeft", None),
		"MarginRight": (102, 2, (4, 0), (), "MarginRight", None),
		"MarginTop": (103, 2, (4, 0), (), "MarginTop", None),
		"NoTextRotation": (118, 2, (3, 0), (), "NoTextRotation", None),
		"Orientation": (104, 2, (3, 0), (), "Orientation", None),
		"Parent": (1, 2, (9, 0), (), "Parent", None),
		"PathFormat": (107, 2, (3, 0), (), "PathFormat", None),
		# Method 'Ruler' returns object of type 'Ruler2'
		"Ruler": (116, 2, (9, 0), (), "Ruler", '{000C03C1-0000-0000-C000-000000000046}'),
		# Method 'TextRange' returns object of type 'TextRange2'
		"TextRange": (114, 2, (9, 0), (), "TextRange", '{000C0397-0000-0000-C000-000000000046}'),
		# Method 'ThreeD' returns object of type 'ThreeDFormat'
		"ThreeD": (112, 2, (9, 0), (), "ThreeD", '{000C0321-0000-0000-C000-000000000046}'),
		"VerticalAnchor": (106, 2, (3, 0), (), "VerticalAnchor", None),
		"WarpFormat": (108, 2, (3, 0), (), "WarpFormat", None),
		"WordArtformat": (109, 2, (3, 0), (), "WordArtformat", None),
		"WordWrap": (110, 2, (3, 0), (), "WordWrap", None),
	}
	_prop_map_put_ = {
		"AutoSize": ((111, LCID, 4, 0),()),
		"HorizontalAnchor": ((105, LCID, 4, 0),()),
		"MarginBottom": ((100, LCID, 4, 0),()),
		"MarginLeft": ((101, LCID, 4, 0),()),
		"MarginRight": ((102, LCID, 4, 0),()),
		"MarginTop": ((103, LCID, 4, 0),()),
		"NoTextRotation": ((118, LCID, 4, 0),()),
		"Orientation": ((104, LCID, 4, 0),()),
		"PathFormat": ((107, LCID, 4, 0),()),
		"VerticalAnchor": ((106, LCID, 4, 0),()),
		"WarpFormat": ((108, LCID, 4, 0),()),
		"WordArtformat": ((109, LCID, 4, 0),()),
		"WordWrap": ((110, LCID, 4, 0),()),
	}
	def __iter__(self):
		"Return a Python iterator for this object"
		try:
			ob = self._oleobj_.InvokeTypes(-4,LCID,3,(13, 10),())
		except pythoncom.error:
			raise TypeError("This object does not support enumeration")
		return win32com.client.util.Iterator(ob, None)

win32com.client.CLSIDToClass.RegisterCLSID( "{000C0398-0000-0000-C000-000000000046}", TextFrame2 )
# -*- coding: mbcs -*-
# Created by makepy.py version 0.5.01
# By python version 2.7.10 (default, May 23 2015, 09:40:32) [MSC v.1500 32 bit (Intel)]
# From type library '{00020813-0000-0000-C000-000000000046}'
# On Thu Jun 11 17:00:48 2015
'Microsoft Excel 15.0 Object Library'
makepy_version = '0.5.01'
python_version = 0x2070af0

import win32com.client.CLSIDToClass, pythoncom, pywintypes
import win32com.client.util
from pywintypes import IID
from win32com.client import Dispatch

# The following 3 lines may need tweaking for the particular server
# Candidates are pythoncom.Missing, .Empty and .ArgNotFound
defaultNamedOptArg=pythoncom.Empty
defaultNamedNotOptArg=pythoncom.Empty
defaultUnnamedArg=pythoncom.Empty

CLSID = IID('{00020813-0000-0000-C000-000000000046}')
MajorVersion = 1
MinorVersion = 8
LibraryFlags = 8
LCID = 0x0

TextFrame2_vtables_dispatch_ = 1
TextFrame2_vtables_ = [
	(( u'Parent' , u'Parent' , ), 1, (1, (), [ (16393, 10, None, None) , ], 1 , 2 , 4 , 0 , 36 , (3, 0, None, None) , 0 , )),
	(( u'MarginBottom' , u'MarginBottom' , ), 100, (100, (), [ (16388, 10, None, None) , ], 1 , 2 , 4 , 0 , 40 , (3, 0, None, None) , 0 , )),
	(( u'MarginBottom' , u'MarginBottom' , ), 100, (100, (), [ (4, 1, None, None) , ], 1 , 4 , 4 , 0 , 44 , (3, 0, None, None) , 0 , )),
	(( u'MarginLeft' , u'MarginLeft' , ), 101, (101, (), [ (16388, 10, None, None) , ], 1 , 2 , 4 , 0 , 48 , (3, 0, None, None) , 0 , )),
	(( u'MarginLeft' , u'MarginLeft' , ), 101, (101, (), [ (4, 1, None, None) , ], 1 , 4 , 4 , 0 , 52 , (3, 0, None, None) , 0 , )),
	(( u'MarginRight' , u'MarginRight' , ), 102, (102, (), [ (16388, 10, None, None) , ], 1 , 2 , 4 , 0 , 56 , (3, 0, None, None) , 0 , )),
	(( u'MarginRight' , u'MarginRight' , ), 102, (102, (), [ (4, 1, None, None) , ], 1 , 4 , 4 , 0 , 60 , (3, 0, None, None) , 0 , )),
	(( u'MarginTop' , u'MarginTop' , ), 103, (103, (), [ (16388, 10, None, None) , ], 1 , 2 , 4 , 0 , 64 , (3, 0, None, None) , 0 , )),
	(( u'MarginTop' , u'MarginTop' , ), 103, (103, (), [ (4, 1, None, None) , ], 1 , 4 , 4 , 0 , 68 , (3, 0, None, None) , 0 , )),
	(( u'Orientation' , u'Orientation' , ), 104, (104, (), [ (16387, 10, None, None) , ], 1 , 2 , 4 , 0 , 72 , (3, 0, None, None) , 0 , )),
	(( u'Orientation' , u'Orientation' , ), 104, (104, (), [ (3, 1, None, None) , ], 1 , 4 , 4 , 0 , 76 , (3, 0, None, None) , 0 , )),
	(( u'HorizontalAnchor' , u'HorizontalAnchor' , ), 105, (105, (), [ (16387, 10, None, None) , ], 1 , 2 , 4 , 0 , 80 , (3, 0, None, None) , 0 , )),
	(( u'HorizontalAnchor' , u'HorizontalAnchor' , ), 105, (105, (), [ (3, 1, None, None) , ], 1 , 4 , 4 , 0 , 84 , (3, 0, None, None) , 0 , )),
	(( u'VerticalAnchor' , u'VerticalAnchor' , ), 106, (106, (), [ (16387, 10, None, None) , ], 1 , 2 , 4 , 0 , 88 , (3, 0, None, None) , 0 , )),
	(( u'VerticalAnchor' , u'VerticalAnchor' , ), 106, (106, (), [ (3, 1, None, None) , ], 1 , 4 , 4 , 0 , 92 , (3, 0, None, None) , 0 , )),
	(( u'PathFormat' , u'PathFormat' , ), 107, (107, (), [ (16387, 10, None, None) , ], 1 , 2 , 4 , 0 , 96 , (3, 0, None, None) , 0 , )),
	(( u'PathFormat' , u'PathFormat' , ), 107, (107, (), [ (3, 1, None, None) , ], 1 , 4 , 4 , 0 , 100 , (3, 0, None, None) , 0 , )),
	(( u'WarpFormat' , u'WarpFormat' , ), 108, (108, (), [ (16387, 10, None, None) , ], 1 , 2 , 4 , 0 , 104 , (3, 0, None, None) , 0 , )),
	(( u'WarpFormat' , u'WarpFormat' , ), 108, (108, (), [ (3, 1, None, None) , ], 1 , 4 , 4 , 0 , 108 , (3, 0, None, None) , 0 , )),
	(( u'WordArtformat' , u'WordArtformat' , ), 109, (109, (), [ (16387, 10, None, None) , ], 1 , 2 , 4 , 0 , 112 , (3, 0, None, None) , 0 , )),
	(( u'WordArtformat' , u'WordArtformat' , ), 109, (109, (), [ (3, 1, None, None) , ], 1 , 4 , 4 , 0 , 116 , (3, 0, None, None) , 0 , )),
	(( u'WordWrap' , u'WordWrap' , ), 110, (110, (), [ (16387, 10, None, None) , ], 1 , 2 , 4 , 0 , 120 , (3, 0, None, None) , 0 , )),
	(( u'WordWrap' , u'WordWrap' , ), 110, (110, (), [ (3, 1, None, None) , ], 1 , 4 , 4 , 0 , 124 , (3, 0, None, None) , 0 , )),
	(( u'AutoSize' , u'AutoSize' , ), 111, (111, (), [ (16387, 10, None, None) , ], 1 , 2 , 4 , 0 , 128 , (3, 0, None, None) , 0 , )),
	(( u'AutoSize' , u'AutoSize' , ), 111, (111, (), [ (3, 1, None, None) , ], 1 , 4 , 4 , 0 , 132 , (3, 0, None, None) , 0 , )),
	(( u'ThreeD' , u'ThreeD' , ), 112, (112, (), [ (16393, 10, None, "IID('{000C0321-0000-0000-C000-000000000046}')") , ], 1 , 2 , 4 , 0 , 136 , (3, 0, None, None) , 0 , )),
	(( u'HasText' , u'pHasText' , ), 113, (113, (), [ (16387, 10, None, None) , ], 1 , 2 , 4 , 0 , 140 , (3, 0, None, None) , 0 , )),
	(( u'TextRange' , u'Range' , ), 114, (114, (), [ (16393, 10, None, "IID('{000C0397-0000-0000-C000-000000000046}')") , ], 1 , 2 , 4 , 0 , 144 , (3, 0, None, None) , 0 , )),
	(( u'Column' , u'Column' , ), 115, (115, (), [ (16393, 10, None, "IID('{000C03B2-0000-0000-C000-000000000046}')") , ], 1 , 2 , 4 , 0 , 148 , (3, 0, None, None) , 0 , )),
	(( u'Ruler' , u'Ruler' , ), 116, (116, (), [ (16393, 10, None, "IID('{000C03C1-0000-0000-C000-000000000046}')") , ], 1 , 2 , 4 , 0 , 152 , (3, 0, None, None) , 0 , )),
	(( u'DeleteText' , ), 117, (117, (), [ ], 1 , 1 , 4 , 0 , 156 , (3, 0, None, None) , 0 , )),
	(( u'NoTextRotation' , u'NoTextRotation' , ), 118, (118, (), [ (16387, 10, None, None) , ], 1 , 2 , 4 , 0 , 160 , (3, 0, None, None) , 0 , )),
	(( u'NoTextRotation' , u'NoTextRotation' , ), 118, (118, (), [ (3, 1, None, None) , ], 1 , 4 , 4 , 0 , 164 , (3, 0, None, None) , 0 , )),
]

win32com.client.CLSIDToClass.RegisterCLSID( "{000C0398-0000-0000-C000-000000000046}", TextFrame2 )
