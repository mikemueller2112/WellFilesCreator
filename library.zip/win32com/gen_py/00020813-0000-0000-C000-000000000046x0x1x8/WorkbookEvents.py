# -*- coding: mbcs -*-
# Created by makepy.py version 0.5.01
# By python version 2.7.10 (default, May 23 2015, 09:40:32) [MSC v.1500 32 bit (Intel)]
# From type library '{00020813-0000-0000-C000-000000000046}'
# On Thu Jun 11 17:00:48 2015
'Microsoft Excel 15.0 Object Library'
makepy_version = '0.5.01'
python_version = 0x2070af0

import win32com.client.CLSIDToClass, pythoncom, pywintypes
import win32com.client.util
from pywintypes import IID
from win32com.client import Dispatch

# The following 3 lines may need tweaking for the particular server
# Candidates are pythoncom.Missing, .Empty and .ArgNotFound
defaultNamedOptArg=pythoncom.Empty
defaultNamedNotOptArg=pythoncom.Empty
defaultUnnamedArg=pythoncom.Empty

CLSID = IID('{00020813-0000-0000-C000-000000000046}')
MajorVersion = 1
MinorVersion = 8
LibraryFlags = 8
LCID = 0x0

class WorkbookEvents:
	CLSID = CLSID_Sink = IID('{00024412-0000-0000-C000-000000000046}')
	coclass_clsid = IID('{00020819-0000-0000-C000-000000000046}')
	_public_methods_ = [] # For COM Server support
	_dispid_to_func_ = {
		     1530 : "OnDeactivate",
		     2266 : "OnSync",
		1610678273 : "OnGetTypeInfo",
		     1549 : "OnBeforePrint",
		     1560 : "OnSheetBeforeRightClick",
		     2896 : "OnSheetPivotTableBeforeAllocateChanges",
		     1854 : "OnSheetFollowHyperlink",
		     2283 : "OnBeforeXmlImport",
		     1558 : "OnSheetSelectionChange",
		1610678275 : "OnInvoke",
		     1561 : "OnSheetActivate",
		     1547 : "OnBeforeSave",
		     2285 : "OnAfterXmlImport",
		     2287 : "OnBeforeXmlExport",
		     2895 : "OnSheetPivotTableAfterValueChange",
		1610612737 : "OnAddRef",
		1610612736 : "OnQueryInterface",
		     1564 : "OnSheetChange",
		     1553 : "OnAddinUninstall",
		     2898 : "OnSheetPivotTableBeforeDiscardChanges",
		     3077 : "OnModelChange",
		     1552 : "OnAddinInstall",
		     2159 : "OnPivotTableOpenConnection",
		     3079 : "OnSheetBeforeDelete",
		     1563 : "OnSheetCalculate",
		     1559 : "OnSheetBeforeDoubleClick",
		     2157 : "OnSheetPivotTableUpdate",
		     1562 : "OnSheetDeactivate",
		     1557 : "OnWindowDeactivate",
		1610612738 : "OnRelease",
		     1554 : "OnWindowResize",
		      304 : "OnActivate",
		     3076 : "OnSheetTableUpdate",
		     2158 : "OnPivotTableCloseConnection",
		     3075 : "OnSheetLensGalleryRenderComplete",
		1610678272 : "OnGetTypeInfoCount",
		     1546 : "OnBeforeClose",
		     1556 : "OnWindowActivate",
		     2900 : "OnAfterSave",
		     2288 : "OnAfterXmlExport",
		     2897 : "OnSheetPivotTableBeforeCommitChanges",
		1610678274 : "OnGetIDsOfNames",
		     1550 : "OnNewSheet",
		     1923 : "OnOpen",
		     2899 : "OnSheetPivotTableChangeSync",
		     2901 : "OnNewChart",
		     2610 : "OnRowsetComplete",
		}

	def __init__(self, oobj = None):
		if oobj is None:
			self._olecp = None
		else:
			import win32com.server.util
			from win32com.server.policy import EventHandlerPolicy
			cpc=oobj._oleobj_.QueryInterface(pythoncom.IID_IConnectionPointContainer)
			cp=cpc.FindConnectionPoint(self.CLSID_Sink)
			cookie=cp.Advise(win32com.server.util.wrap(self, usePolicy=EventHandlerPolicy))
			self._olecp,self._olecp_cookie = cp,cookie
	def __del__(self):
		try:
			self.close()
		except pythoncom.com_error:
			pass
	def close(self):
		if self._olecp is not None:
			cp,cookie,self._olecp,self._olecp_cookie = self._olecp,self._olecp_cookie,None,None
			cp.Unadvise(cookie)
	def _query_interface_(self, iid):
		import win32com.server.util
		if iid==self.CLSID_Sink: return win32com.server.util.wrap(self)

	# Event Handlers
	# If you create handlers, they should have the following prototypes:
#	def OnDeactivate(self):
#	def OnSync(self, SyncEventType=defaultNamedNotOptArg):
#	def OnGetTypeInfo(self, itinfo=defaultNamedNotOptArg, lcid=defaultNamedNotOptArg, pptinfo=pythoncom.Missing):
#	def OnBeforePrint(self, Cancel=defaultNamedNotOptArg):
#	def OnSheetBeforeRightClick(self, Sh=defaultNamedNotOptArg, Target=defaultNamedNotOptArg, Cancel=defaultNamedNotOptArg):
#	def OnSheetPivotTableBeforeAllocateChanges(self, Sh=defaultNamedNotOptArg, TargetPivotTable=defaultNamedNotOptArg, ValueChangeStart=defaultNamedNotOptArg, ValueChangeEnd=defaultNamedNotOptArg
#			, Cancel=defaultNamedNotOptArg):
#	def OnSheetFollowHyperlink(self, Sh=defaultNamedNotOptArg, Target=defaultNamedNotOptArg):
#	def OnBeforeXmlImport(self, Map=defaultNamedNotOptArg, Url=defaultNamedNotOptArg, IsRefresh=defaultNamedNotOptArg, Cancel=defaultNamedNotOptArg):
#	def OnSheetSelectionChange(self, Sh=defaultNamedNotOptArg, Target=defaultNamedNotOptArg):
#	def OnInvoke(self, dispidMember=defaultNamedNotOptArg, riid=defaultNamedNotOptArg, lcid=defaultNamedNotOptArg, wFlags=defaultNamedNotOptArg
#			, pdispparams=defaultNamedNotOptArg, pvarResult=pythoncom.Missing, pexcepinfo=pythoncom.Missing, puArgErr=pythoncom.Missing):
#	def OnSheetActivate(self, Sh=defaultNamedNotOptArg):
#	def OnBeforeSave(self, SaveAsUI=defaultNamedNotOptArg, Cancel=defaultNamedNotOptArg):
#	def OnAfterXmlImport(self, Map=defaultNamedNotOptArg, IsRefresh=defaultNamedNotOptArg, Result=defaultNamedNotOptArg):
#	def OnBeforeXmlExport(self, Map=defaultNamedNotOptArg, Url=defaultNamedNotOptArg, Cancel=defaultNamedNotOptArg):
#	def OnSheetPivotTableAfterValueChange(self, Sh=defaultNamedNotOptArg, TargetPivotTable=defaultNamedNotOptArg, TargetRange=defaultNamedNotOptArg):
#	def OnAddRef(self):
#	def OnQueryInterface(self, riid=defaultNamedNotOptArg, ppvObj=pythoncom.Missing):
#	def OnSheetChange(self, Sh=defaultNamedNotOptArg, Target=defaultNamedNotOptArg):
#	def OnAddinUninstall(self):
#	def OnSheetPivotTableBeforeDiscardChanges(self, Sh=defaultNamedNotOptArg, TargetPivotTable=defaultNamedNotOptArg, ValueChangeStart=defaultNamedNotOptArg, ValueChangeEnd=defaultNamedNotOptArg):
#	def OnModelChange(self, Changes=defaultNamedNotOptArg):
#	def OnAddinInstall(self):
#	def OnPivotTableOpenConnection(self, Target=defaultNamedNotOptArg):
#	def OnSheetBeforeDelete(self, Sh=defaultNamedNotOptArg):
#	def OnSheetCalculate(self, Sh=defaultNamedNotOptArg):
#	def OnSheetBeforeDoubleClick(self, Sh=defaultNamedNotOptArg, Target=defaultNamedNotOptArg, Cancel=defaultNamedNotOptArg):
#	def OnSheetPivotTableUpdate(self, Sh=defaultNamedNotOptArg, Target=defaultNamedNotOptArg):
#	def OnSheetDeactivate(self, Sh=defaultNamedNotOptArg):
#	def OnWindowDeactivate(self, Wn=defaultNamedNotOptArg):
#	def OnRelease(self):
#	def OnWindowResize(self, Wn=defaultNamedNotOptArg):
#	def OnActivate(self):
#	def OnSheetTableUpdate(self, Sh=defaultNamedNotOptArg, Target=defaultNamedNotOptArg):
#	def OnPivotTableCloseConnection(self, Target=defaultNamedNotOptArg):
#	def OnSheetLensGalleryRenderComplete(self, Sh=defaultNamedNotOptArg):
#	def OnGetTypeInfoCount(self, pctinfo=pythoncom.Missing):
#	def OnBeforeClose(self, Cancel=defaultNamedNotOptArg):
#	def OnWindowActivate(self, Wn=defaultNamedNotOptArg):
#	def OnAfterSave(self, Success=defaultNamedNotOptArg):
#	def OnAfterXmlExport(self, Map=defaultNamedNotOptArg, Url=defaultNamedNotOptArg, Result=defaultNamedNotOptArg):
#	def OnSheetPivotTableBeforeCommitChanges(self, Sh=defaultNamedNotOptArg, TargetPivotTable=defaultNamedNotOptArg, ValueChangeStart=defaultNamedNotOptArg, ValueChangeEnd=defaultNamedNotOptArg
#			, Cancel=defaultNamedNotOptArg):
#	def OnGetIDsOfNames(self, riid=defaultNamedNotOptArg, rgszNames=defaultNamedNotOptArg, cNames=defaultNamedNotOptArg, lcid=defaultNamedNotOptArg
#			, rgdispid=pythoncom.Missing):
#	def OnNewSheet(self, Sh=defaultNamedNotOptArg):
#	def OnOpen(self):
#	def OnSheetPivotTableChangeSync(self, Sh=defaultNamedNotOptArg, Target=defaultNamedNotOptArg):
#	def OnNewChart(self, Ch=defaultNamedNotOptArg):
#	def OnRowsetComplete(self, Description=defaultNamedNotOptArg, Sheet=defaultNamedNotOptArg, Success=defaultNamedNotOptArg):


win32com.client.CLSIDToClass.RegisterCLSID( "{00024412-0000-0000-C000-000000000046}", WorkbookEvents )
