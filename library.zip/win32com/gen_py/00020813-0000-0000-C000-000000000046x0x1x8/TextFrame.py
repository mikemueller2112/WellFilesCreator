# -*- coding: mbcs -*-
# Created by makepy.py version 0.5.01
# By python version 2.7.10 (default, May 23 2015, 09:40:32) [MSC v.1500 32 bit (Intel)]
# From type library '{00020813-0000-0000-C000-000000000046}'
# On Thu Jun 11 17:00:49 2015
'Microsoft Excel 15.0 Object Library'
makepy_version = '0.5.01'
python_version = 0x2070af0

import win32com.client.CLSIDToClass, pythoncom, pywintypes
import win32com.client.util
from pywintypes import IID
from win32com.client import Dispatch

# The following 3 lines may need tweaking for the particular server
# Candidates are pythoncom.Missing, .Empty and .ArgNotFound
defaultNamedOptArg=pythoncom.Empty
defaultNamedNotOptArg=pythoncom.Empty
defaultUnnamedArg=pythoncom.Empty

CLSID = IID('{00020813-0000-0000-C000-000000000046}')
MajorVersion = 1
MinorVersion = 8
LibraryFlags = 8
LCID = 0x0

from win32com.client import DispatchBaseClass
class TextFrame(DispatchBaseClass):
	CLSID = IID('{0002443D-0000-0000-C000-000000000046}')
	coclass_clsid = None

	# Result is of type Characters
	def Characters(self, Start=defaultNamedOptArg, Length=defaultNamedOptArg):
		ret = self._oleobj_.InvokeTypes(603, LCID, 1, (9, 0), ((12, 17), (12, 17)),Start
			, Length)
		if ret is not None:
			ret = Dispatch(ret, u'Characters', '{00020878-0000-0000-C000-000000000046}')
		return ret

	_prop_map_get_ = {
		# Method 'Application' returns object of type 'Application'
		"Application": (148, 2, (13, 0), (), "Application", '{00024500-0000-0000-C000-000000000046}'),
		"AutoMargins": (1749, 2, (11, 0), (), "AutoMargins", None),
		"AutoSize": (614, 2, (11, 0), (), "AutoSize", None),
		"Creator": (149, 2, (3, 0), (), "Creator", None),
		"HorizontalAlignment": (136, 2, (3, 0), (), "HorizontalAlignment", None),
		"HorizontalOverflow": (2923, 2, (3, 0), (), "HorizontalOverflow", None),
		"MarginBottom": (1745, 2, (4, 0), (), "MarginBottom", None),
		"MarginLeft": (1746, 2, (4, 0), (), "MarginLeft", None),
		"MarginRight": (1747, 2, (4, 0), (), "MarginRight", None),
		"MarginTop": (1748, 2, (4, 0), (), "MarginTop", None),
		"Orientation": (134, 2, (3, 0), (), "Orientation", None),
		"Parent": (150, 2, (9, 0), (), "Parent", None),
		"ReadingOrder": (975, 2, (3, 0), (), "ReadingOrder", None),
		"VerticalAlignment": (137, 2, (3, 0), (), "VerticalAlignment", None),
		"VerticalOverflow": (2922, 2, (3, 0), (), "VerticalOverflow", None),
	}
	_prop_map_put_ = {
		"AutoMargins": ((1749, LCID, 4, 0),()),
		"AutoSize": ((614, LCID, 4, 0),()),
		"HorizontalAlignment": ((136, LCID, 4, 0),()),
		"HorizontalOverflow": ((2923, LCID, 4, 0),()),
		"MarginBottom": ((1745, LCID, 4, 0),()),
		"MarginLeft": ((1746, LCID, 4, 0),()),
		"MarginRight": ((1747, LCID, 4, 0),()),
		"MarginTop": ((1748, LCID, 4, 0),()),
		"Orientation": ((134, LCID, 4, 0),()),
		"ReadingOrder": ((975, LCID, 4, 0),()),
		"VerticalAlignment": ((137, LCID, 4, 0),()),
		"VerticalOverflow": ((2922, LCID, 4, 0),()),
	}
	def __iter__(self):
		"Return a Python iterator for this object"
		try:
			ob = self._oleobj_.InvokeTypes(-4,LCID,3,(13, 10),())
		except pythoncom.error:
			raise TypeError("This object does not support enumeration")
		return win32com.client.util.Iterator(ob, None)

win32com.client.CLSIDToClass.RegisterCLSID( "{0002443D-0000-0000-C000-000000000046}", TextFrame )
